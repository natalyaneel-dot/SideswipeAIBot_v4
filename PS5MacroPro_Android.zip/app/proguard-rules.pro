# Keep app classes
-keep class com.ps5macro.app.** { *; }
