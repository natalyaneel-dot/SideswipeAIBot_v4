package com.ps5macro.app;

import android.view.KeyEvent;

public final class KeyCodeHelper {

    public static final int[] COMMON_KEY_CODES = new int[]{
            KeyEvent.KEYCODE_BUTTON_R1,
            KeyEvent.KEYCODE_BUTTON_L1,
            KeyEvent.KEYCODE_BUTTON_R2,
            KeyEvent.KEYCODE_BUTTON_L2,
            KeyEvent.KEYCODE_BUTTON_THUMBL,
            KeyEvent.KEYCODE_BUTTON_THUMBR,
            KeyEvent.KEYCODE_BUTTON_A,
            KeyEvent.KEYCODE_BUTTON_B,
            KeyEvent.KEYCODE_BUTTON_X,
            KeyEvent.KEYCODE_BUTTON_Y,
            KeyEvent.KEYCODE_BUTTON_SELECT,
            KeyEvent.KEYCODE_BUTTON_START,
            KeyEvent.KEYCODE_DPAD_UP,
            KeyEvent.KEYCODE_DPAD_DOWN,
            KeyEvent.KEYCODE_DPAD_LEFT,
            KeyEvent.KEYCODE_DPAD_RIGHT
    };

    public static final String[] COMMON_KEY_LABELS = new String[]{
            "R1",
            "L1",
            "R2",
            "L2",
            "L3 (ضغط الأنالوج الأيسر)",
            "R3 (ضغط الأنالوج الأيمن)",
            "✕ Cross (A)",
            "○ Circle (B)",
            "□ Square (X)",
            "△ Triangle (Y)",
            "Create / Share",
            "Options",
            "سهم أعلى (D-Pad Up)",
            "سهم أسفل (D-Pad Down)",
            "سهم يسار (D-Pad Left)",
            "سهم يمين (D-Pad Right)"
    };

    private KeyCodeHelper() {
    }

    public static String getFriendlyName(int keyCode) {
        for (int i = 0; i < COMMON_KEY_CODES.length; i++) {
            if (COMMON_KEY_CODES[i] == keyCode) {
                return COMMON_KEY_LABELS[i] + " [" + keyCode + "]";
            }
        }
        return KeyEvent.keyCodeToString(keyCode) + " [" + keyCode + "]";
    }

    public static int getSpinnerIndexForKeyCode(int keyCode) {
        for (int i = 0; i < COMMON_KEY_CODES.length; i++) {
            if (COMMON_KEY_CODES[i] == keyCode) {
                return i;
            }
        }
        return -1;
    }

    public static boolean isDisallowedBindKey(int keyCode) {
        return keyCode == KeyEvent.KEYCODE_HOME
                || keyCode == KeyEvent.KEYCODE_POWER
                || keyCode == KeyEvent.KEYCODE_VOLUME_UP
                || keyCode == KeyEvent.KEYCODE_VOLUME_DOWN
                || keyCode == KeyEvent.KEYCODE_VOLUME_MUTE
                || keyCode == KeyEvent.KEYCODE_APP_SWITCH;
    }
}
