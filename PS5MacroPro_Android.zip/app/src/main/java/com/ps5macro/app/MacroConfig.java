package com.ps5macro.app;

import android.content.Context;
import android.content.SharedPreferences;
import android.view.KeyEvent;

public class MacroConfig {

    private static final String PREFS_NAME = "ps5_macro_pro_prefs";
    private static final String KEY_ACTIVE_SLOT = "active_slot";

    public int slotIndex = 0;
    public int triggerKeyCode = KeyEvent.KEYCODE_BUTTON_R1;
    public int buttonCount = 2;
    public boolean consumeTrigger = false;

    public int delay1to2 = 50;
    public int delay2to3 = 50;

    public int hold1 = 45;
    public int hold2 = 45;
    public int hold3 = 45;

    public int cooldownMs = 150;

    public int x1 = 350;
    public int y1 = 450;
    public int x2 = 550;
    public int y2 = 450;
    public int x3 = 750;
    public int y3 = 450;

    public static int getActiveSlot(Context context) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        return clamp(prefs.getInt(KEY_ACTIVE_SLOT, 0), 0, 2);
    }

    public static void setActiveSlot(Context context, int slot) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        prefs.edit().putInt(KEY_ACTIVE_SLOT, clamp(slot, 0, 2)).apply();
    }

    public static MacroConfig load(Context context) {
        return loadSlot(context, getActiveSlot(context));
    }

    public static MacroConfig loadSlot(Context context, int slot) {
        int safeSlot = clamp(slot, 0, 2);
        SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        String p = "slot_" + safeSlot + "_";

        MacroConfig cfg = new MacroConfig();
        cfg.slotIndex = safeSlot;
        cfg.triggerKeyCode = prefs.getInt(p + "trigger", KeyEvent.KEYCODE_BUTTON_R1);
        cfg.buttonCount = clamp(prefs.getInt(p + "count", 2), 2, 3);
        cfg.consumeTrigger = prefs.getBoolean(p + "consume", false);

        cfg.delay1to2 = clamp(prefs.getInt(p + "delay12", 50), 0, 5000);
        cfg.delay2to3 = clamp(prefs.getInt(p + "delay23", 50), 0, 5000);

        cfg.hold1 = clamp(prefs.getInt(p + "hold1", 45), 20, 2000);
        cfg.hold2 = clamp(prefs.getInt(p + "hold2", 45), 20, 2000);
        cfg.hold3 = clamp(prefs.getInt(p + "hold3", 45), 20, 2000);

        cfg.cooldownMs = clamp(prefs.getInt(p + "cooldown", 150), 50, 3000);

        cfg.x1 = prefs.getInt(p + "x1", 350);
        cfg.y1 = prefs.getInt(p + "y1", 450);
        cfg.x2 = prefs.getInt(p + "x2", 550);
        cfg.y2 = prefs.getInt(p + "y2", 450);
        cfg.x3 = prefs.getInt(p + "x3", 750);
        cfg.y3 = prefs.getInt(p + "y3", 450);
        return cfg;
    }

    public void save(Context context) {
        int safeSlot = clamp(slotIndex, 0, 2);
        SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        String p = "slot_" + safeSlot + "_";

        buttonCount = clamp(buttonCount, 2, 3);
        delay1to2 = clamp(delay1to2, 0, 5000);
        delay2to3 = clamp(delay2to3, 0, 5000);
        hold1 = clamp(hold1, 20, 2000);
        hold2 = clamp(hold2, 20, 2000);
        hold3 = clamp(hold3, 20, 2000);
        cooldownMs = clamp(cooldownMs, 50, 3000);

        prefs.edit()
                .putInt(KEY_ACTIVE_SLOT, safeSlot)
                .putInt(p + "trigger", triggerKeyCode)
                .putInt(p + "count", buttonCount)
                .putBoolean(p + "consume", consumeTrigger)
                .putInt(p + "delay12", delay1to2)
                .putInt(p + "delay23", delay2to3)
                .putInt(p + "hold1", hold1)
                .putInt(p + "hold2", hold2)
                .putInt(p + "hold3", hold3)
                .putInt(p + "cooldown", cooldownMs)
                .putInt(p + "x1", x1)
                .putInt(p + "y1", y1)
                .putInt(p + "x2", x2)
                .putInt(p + "y2", y2)
                .putInt(p + "x3", x3)
                .putInt(p + "y3", y3)
                .apply();
    }

    public static int clamp(int value, int min, int max) {
        if (value < min) {
            return min;
        }
        if (value > max) {
            return max;
        }
        return value;
    }
}
