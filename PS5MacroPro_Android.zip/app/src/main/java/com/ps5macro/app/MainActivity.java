package com.ps5macro.app;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.text.TextUtils;
import android.view.KeyEvent;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

public class MainActivity extends AppCompatActivity {

    private TextView tvAccessibilityStatus;
    private TextView tvOverlayStatus;
    private TextView tvCurrentTrigger;
    private TextView tvLastKeyPressed;

    private Button btnSlot1;
    private Button btnSlot2;
    private Button btnSlot3;
    private Button btnBindPs5Key;

    private Spinner spinnerTriggerKey;
    private CheckBox cbConsumeTrigger;

    private RadioGroup rgButtonCount;
    private RadioButton rbTwoButtons;
    private RadioButton rbThreeButtons;

    private EditText etDelay1to2;
    private EditText etDelay2to3;
    private EditText etHold1;
    private EditText etHold2;
    private EditText etHold3;
    private EditText etCooldown;

    private LinearLayout layoutDelay2to3;
    private LinearLayout layoutHold3;

    private MacroConfig config;
    private boolean isListeningForKey = false;
    private boolean ignoreNextSpinnerEvent = false;
    private int lastConsumedBindKeyCode = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        bindViews();
        setupSpinner();
        setupListeners();

        config = MacroConfig.load(this);
        populateUiFromConfig();
    }

    @Override
    protected void onResume() {
        super.onResume();
        updatePermissionStatus();
    }

    private void bindViews() {
        tvAccessibilityStatus = findViewById(R.id.tvAccessibilityStatus);
        tvOverlayStatus = findViewById(R.id.tvOverlayStatus);
        tvCurrentTrigger = findViewById(R.id.tvCurrentTrigger);
        tvLastKeyPressed = findViewById(R.id.tvLastKeyPressed);

        btnSlot1 = findViewById(R.id.btnSlot1);
        btnSlot2 = findViewById(R.id.btnSlot2);
        btnSlot3 = findViewById(R.id.btnSlot3);
        btnBindPs5Key = findViewById(R.id.btnBindPs5Key);

        spinnerTriggerKey = findViewById(R.id.spinnerTriggerKey);
        cbConsumeTrigger = findViewById(R.id.cbConsumeTrigger);

        rgButtonCount = findViewById(R.id.rgButtonCount);
        rbTwoButtons = findViewById(R.id.rbTwoButtons);
        rbThreeButtons = findViewById(R.id.rbThreeButtons);

        etDelay1to2 = findViewById(R.id.etDelay1to2);
        etDelay2to3 = findViewById(R.id.etDelay2to3);
        etHold1 = findViewById(R.id.etHold1);
        etHold2 = findViewById(R.id.etHold2);
        etHold3 = findViewById(R.id.etHold3);
        etCooldown = findViewById(R.id.etCooldown);

        layoutDelay2to3 = findViewById(R.id.layoutDelay2to3);
        layoutHold3 = findViewById(R.id.layoutHold3);
    }

    private void setupSpinner() {
        ArrayAdapter<String> adapter = new ArrayAdapter<>(
                this,
                R.layout.item_spinner,
                KeyCodeHelper.COMMON_KEY_LABELS
        );
        adapter.setDropDownViewResource(R.layout.item_spinner);
        spinnerTriggerKey.setAdapter(adapter);
    }

    private void setupListeners() {
        Button btnEnableAccessibility = findViewById(R.id.btnEnableAccessibility);
        Button btnEnableOverlay = findViewById(R.id.btnEnableOverlay);
        Button btnSaveSettings = findViewById(R.id.btnSaveSettings);
        Button btnStartOverlay = findViewById(R.id.btnStartOverlay);
        Button btnStopOverlay = findViewById(R.id.btnStopOverlay);

        btnEnableAccessibility.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
            }
        });

        btnEnableOverlay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(
                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + getPackageName())
                );
                startActivity(intent);
            }
        });

        btnSlot1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                switchSlot(0);
            }
        });
        btnSlot2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                switchSlot(1);
            }
        });
        btnSlot3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                switchSlot(2);
            }
        });

        btnBindPs5Key.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                isListeningForKey = !isListeningForKey;
                updateBindButtonUi();
            }
        });

        spinnerTriggerKey.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (ignoreNextSpinnerEvent) {
                    ignoreNextSpinnerEvent = false;
                    return;
                }
                if (position >= 0 && position < KeyCodeHelper.COMMON_KEY_CODES.length) {
                    int selectedCode = KeyCodeHelper.COMMON_KEY_CODES[position];
                    if (config.triggerKeyCode != selectedCode) {
                        config.triggerKeyCode = selectedCode;
                        tvCurrentTrigger.setText("الزر الحالي: " + KeyCodeHelper.getFriendlyName(config.triggerKeyCode));
                    }
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });

        rgButtonCount.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                boolean three = (checkedId == R.id.rbThreeButtons);
                layoutDelay2to3.setVisibility(three ? View.VISIBLE : View.GONE);
                layoutHold3.setVisibility(three ? View.VISIBLE : View.GONE);
            }
        });

        setupStepButton(R.id.btnDelay12Minus50, etDelay1to2, -50);
        setupStepButton(R.id.btnDelay12Minus10, etDelay1to2, -10);
        setupStepButton(R.id.btnDelay12Plus10, etDelay1to2, 10);
        setupStepButton(R.id.btnDelay12Plus50, etDelay1to2, 50);

        setupStepButton(R.id.btnDelay23Minus50, etDelay2to3, -50);
        setupStepButton(R.id.btnDelay23Minus10, etDelay2to3, -10);
        setupStepButton(R.id.btnDelay23Plus10, etDelay2to3, 10);
        setupStepButton(R.id.btnDelay23Plus50, etDelay2to3, 50);

        btnSaveSettings.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveUiToConfig();
                Toast.makeText(MainActivity.this, "تم حفظ إعدادات الماكرو بنجاح", Toast.LENGTH_SHORT).show();
            }
        });

        btnStartOverlay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveUiToConfig();
                MacroAccessibilityService service = MacroAccessibilityService.getInstance();
                if (service == null) {
                    Toast.makeText(MainActivity.this,
                            "يرجى تفعيل خدمة إمكانية الوصول (PS5 Macro Pro) أولاً",
                            Toast.LENGTH_LONG).show();
                    startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
                    return;
                }
                service.showOverlay();
            }
        });

        btnStopOverlay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MacroAccessibilityService service = MacroAccessibilityService.getInstance();
                if (service != null) {
                    service.hideOverlay();
                }
                Toast.makeText(MainActivity.this, "تم إخفاء النقاط وإيقاف الماكرو", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void setupStepButton(int buttonId, final EditText target, final int delta) {
        Button btn = findViewById(buttonId);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int current = parseIntSafe(target.getText().toString(), 50);
                int next = MacroConfig.clamp(current + delta, 0, 5000);
                target.setText(String.valueOf(next));
            }
        });
    }

    private void switchSlot(int newSlot) {
        saveUiToConfig();
        MacroConfig.setActiveSlot(this, newSlot);
        config = MacroConfig.loadSlot(this, newSlot);
        populateUiFromConfig();
        MacroAccessibilityService service = MacroAccessibilityService.getInstance();
        if (service != null) {
            service.reloadConfig();
        }
    }

    private void populateUiFromConfig() {
        updateSlotButtonsUi(config.slotIndex);

        tvCurrentTrigger.setText("الزر الحالي: " + KeyCodeHelper.getFriendlyName(config.triggerKeyCode));
        int idx = KeyCodeHelper.getSpinnerIndexForKeyCode(config.triggerKeyCode);
        if (idx >= 0 && spinnerTriggerKey.getSelectedItemPosition() != idx) {
            ignoreNextSpinnerEvent = true;
            spinnerTriggerKey.setSelection(idx);
        }

        cbConsumeTrigger.setChecked(config.consumeTrigger);

        boolean three = (config.buttonCount == 3);
        rbThreeButtons.setChecked(three);
        rbTwoButtons.setChecked(!three);
        layoutDelay2to3.setVisibility(three ? View.VISIBLE : View.GONE);
        layoutHold3.setVisibility(three ? View.VISIBLE : View.GONE);

        etDelay1to2.setText(String.valueOf(config.delay1to2));
        etDelay2to3.setText(String.valueOf(config.delay2to3));
        etHold1.setText(String.valueOf(config.hold1));
        etHold2.setText(String.valueOf(config.hold2));
        etHold3.setText(String.valueOf(config.hold3));
        etCooldown.setText(String.valueOf(config.cooldownMs));
    }

    private void saveUiToConfig() {
        config.buttonCount = rbThreeButtons.isChecked() ? 3 : 2;
        config.consumeTrigger = cbConsumeTrigger.isChecked();
        config.delay1to2 = MacroConfig.clamp(parseIntSafe(etDelay1to2.getText().toString(), 50), 0, 5000);
        config.delay2to3 = MacroConfig.clamp(parseIntSafe(etDelay2to3.getText().toString(), 50), 0, 5000);
        config.hold1 = MacroConfig.clamp(parseIntSafe(etHold1.getText().toString(), 45), 20, 2000);
        config.hold2 = MacroConfig.clamp(parseIntSafe(etHold2.getText().toString(), 45), 20, 2000);
        config.hold3 = MacroConfig.clamp(parseIntSafe(etHold3.getText().toString(), 45), 20, 2000);
        config.cooldownMs = MacroConfig.clamp(parseIntSafe(etCooldown.getText().toString(), 150), 50, 3000);

        config.save(this);
        populateUiFromConfig();

        MacroAccessibilityService service = MacroAccessibilityService.getInstance();
        if (service != null) {
            service.reloadConfig();
        }
    }

    private void updateSlotButtonsUi(int active) {
        btnSlot1.setBackgroundResource(active == 0 ? R.drawable.bg_button_primary : R.drawable.bg_button_secondary);
        btnSlot2.setBackgroundResource(active == 1 ? R.drawable.bg_button_primary : R.drawable.bg_button_secondary);
        btnSlot3.setBackgroundResource(active == 2 ? R.drawable.bg_button_primary : R.drawable.bg_button_secondary);
    }

    private void updateBindButtonUi() {
        if (isListeningForKey) {
            btnBindPs5Key.setText("بانتظار ضغطة زر من يد PS5 الآن... (اضغط للإلغاء)");
            btnBindPs5Key.setBackgroundResource(R.drawable.bg_button_green);
        } else {
            btnBindPs5Key.setText("اضغط هنا ثم اضغط أي زر في يد PS5 للتعيين");
            btnBindPs5Key.setBackgroundResource(R.drawable.bg_button_primary);
        }
    }

    @Override
    public boolean dispatchKeyEvent(KeyEvent event) {
        if (event != null) {
            int keyCode = event.getKeyCode();
            if (event.getAction() == KeyEvent.ACTION_UP && keyCode == lastConsumedBindKeyCode) {
                lastConsumedBindKeyCode = -1;
                return true;
            }
            if (event.getAction() == KeyEvent.ACTION_DOWN && !KeyCodeHelper.isDisallowedBindKey(keyCode)) {
                tvLastKeyPressed.setText("آخر زر تم ضغطه: " + KeyCodeHelper.getFriendlyName(keyCode));

                if (isListeningForKey && keyCode != KeyEvent.KEYCODE_BACK) {
                    config.triggerKeyCode = keyCode;
                    isListeningForKey = false;
                    lastConsumedBindKeyCode = keyCode;
                    updateBindButtonUi();
                    tvCurrentTrigger.setText("الزر الحالي: " + KeyCodeHelper.getFriendlyName(keyCode));
                    int idx = KeyCodeHelper.getSpinnerIndexForKeyCode(keyCode);
                    if (idx >= 0 && spinnerTriggerKey.getSelectedItemPosition() != idx) {
                        ignoreNextSpinnerEvent = true;
                        spinnerTriggerKey.setSelection(idx);
                    }
                    config.save(this);
                    MacroAccessibilityService service = MacroAccessibilityService.getInstance();
                    if (service != null) {
                        service.reloadConfig();
                    }
                    Toast.makeText(this, "تم تعيين زر التفعيل: " + KeyCodeHelper.getFriendlyName(keyCode), Toast.LENGTH_SHORT).show();
                    return true;
                }
            }
        }
        return super.dispatchKeyEvent(event);
    }

    private void updatePermissionStatus() {
        boolean accEnabled = isAccessibilityServiceEnabled();
        if (accEnabled) {
            tvAccessibilityStatus.setText("خدمة إمكانية الوصول: مفعّلة ✓");
            tvAccessibilityStatus.setTextColor(ContextCompat.getColor(this, R.color.accent_green));
        } else {
            tvAccessibilityStatus.setText("خدمة إمكانية الوصول: غير مفعّلة ✕");
            tvAccessibilityStatus.setTextColor(ContextCompat.getColor(this, R.color.accent_red));
        }

        boolean overlayEnabled = Settings.canDrawOverlays(this);
        if (overlayEnabled) {
            tvOverlayStatus.setText("الظهور فوق التطبيقات: مفعّل ✓");
            tvOverlayStatus.setTextColor(ContextCompat.getColor(this, R.color.accent_green));
        } else {
            tvOverlayStatus.setText("الظهور فوق التطبيقات: غير مفعّل (يُفضّل تفعيله)");
            tvOverlayStatus.setTextColor(ContextCompat.getColor(this, R.color.accent_orange));
        }
    }

    private boolean isAccessibilityServiceEnabled() {
        if (MacroAccessibilityService.getInstance() != null) {
            return true;
        }
        String expected = getPackageName() + "/" + MacroAccessibilityService.class.getName();
        String expectedShort = getPackageName() + "/." + MacroAccessibilityService.class.getSimpleName();
        String enabled = Settings.Secure.getString(
                getContentResolver(),
                Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        );
        if (TextUtils.isEmpty(enabled)) {
            return false;
        }
        return enabled.contains(expected) || enabled.contains(expectedShort);
    }

    private int parseIntSafe(String raw, int fallback) {
        if (raw == null || raw.trim().isEmpty()) {
            return fallback;
        }
        try {
            return Integer.parseInt(raw.trim());
        } catch (NumberFormatException e) {
            return fallback;
        }
    }
}
