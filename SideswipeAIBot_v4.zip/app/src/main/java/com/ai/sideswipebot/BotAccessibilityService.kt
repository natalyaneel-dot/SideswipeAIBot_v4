package com.ai.sideswipebot

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.view.accessibility.AccessibilityEvent
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.sin

class BotAccessibilityService : AccessibilityService() {

    companion object {
        var instance: BotAccessibilityService? = null
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {
        instance = null
    }

    override fun onDestroy() {
        super.onDestroy()
        instance = null
    }

    fun executeAction(action: BotAction, screenW: Int, screenH: Int) {
        if (BotConfig.isPaused) return

        val builder = GestureDescription.Builder()
        var hasStroke = false

        // 1. التحكم بعصا التوجيه اليسرى (إلا إذا كانت الحركة تتطلب تحرير العصا بالكامل مثل Stall / Purple)
        val magnitude = hypot(action.stickX, action.stickY)
        if (!action.neutralStick && magnitude >= 0.05f) {
            val stickCenterX = screenW * 0.16f
            val stickCenterY = screenH * 0.74f
            val stickRadius = screenH * 0.125f

            val endX = (stickCenterX + action.stickX * stickRadius).coerceIn(10f, screenW - 10f)
            val endY = (stickCenterY + action.stickY * stickRadius).coerceIn(10f, screenH - 10f)

            val stickPath = Path()
            if (abs(action.sweepArcRad) > 0.05f) {
                // رسم مسار دائري ناعم لحركة 360° لضمان دوران السيارة بدقة عالية
                val endAngle = atan2(action.stickY, action.stickX)
                val startAngle = endAngle - action.sweepArcRad
                val midAngle = startAngle + action.sweepArcRad * 0.5f

                val sx = (stickCenterX + cos(startAngle) * stickRadius).coerceIn(10f, screenW - 10f)
                val sy = (stickCenterY + sin(startAngle) * stickRadius).coerceIn(10f, screenH - 10f)
                val mx = (stickCenterX + cos(midAngle) * stickRadius).coerceIn(10f, screenW - 10f)
                val my = (stickCenterY + sin(midAngle) * stickRadius).coerceIn(10f, screenH - 10f)

                stickPath.moveTo(sx, sy)
                stickPath.quadTo(mx, my, endX, endY)
            } else {
                stickPath.moveTo(stickCenterX, stickCenterY)
                stickPath.lineTo(endX, endY)
            }

            builder.addStroke(GestureDescription.StrokeDescription(stickPath, 0L, 32L))
            hasStroke = true
        }

        // 2. زر القفز (Jump / Dodge / Stall)
        if (action.jump) {
            val jumpX = screenW * 0.88f
            val jumpY = screenH * 0.76f
            val jumpPath = Path().apply {
                moveTo(jumpX, jumpY)
                lineTo(jumpX + 2f, jumpY + 2f)
            }
            builder.addStroke(GestureDescription.StrokeDescription(jumpPath, 0L, 28L))
            hasStroke = true
        }

        // 3. زر التيربو (Boost)
        if (action.boost) {
            val boostX = screenW * 0.77f
            val boostY = screenH * 0.80f
            val boostPath = Path().apply {
                moveTo(boostX, boostY)
                lineTo(boostX + 2f, boostY + 2f)
            }
            builder.addStroke(GestureDescription.StrokeDescription(boostPath, 0L, 32L))
            hasStroke = true
        }

        if (hasStroke) {
            dispatchGesture(builder.build(), null, null)
        }
    }
}
