package com.ai.sideswipebot

import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.sin

data class Point2D(val x: Float, val y: Float)

data class BotAction(
    val stickX: Float,
    val stickY: Float,
    val jump: Boolean,
    val boost: Boolean,
    val neutralStick: Boolean = false,   // تحرير العصا للمنتصف لتنفيذ Stall أو Purple Shot
    val sweepArcRad: Float = 0f          // زاوية الدوران المستمر في هذا الإطار (لحركة 360)
)

private enum class MechanicState {
    NORMAL,
    FAST_KICKOFF,
    SPIN_360,
    GOLD_SHOT,
    PURPLE_SHOT,
    STALL_RESET,
    SHADOW_DEFENSE
}

class BotBrain {
    private var prevBall: Point2D? = null
    private var prevTimeMs: Long = 0L
    private var smoothVx: Float = 0f
    private var smoothVy: Float = 0f

    private var lastJumpTimeMs: Long = 0L
    private var jumpCount: Int = 0

    private var mechanicState: MechanicState = MechanicState.NORMAL
    private var mechanicStartMs: Long = 0L
    private var lastMechanicEndMs: Long = 0L
    private var spinDirection: Float = 1f
    private var lastSpinAngle: Float = 0f

    fun decide(
        ball: Point2D?,
        car: Point2D?,
        screenW: Int,
        screenH: Int,
        nowMs: Long
    ): BotAction {
        if (BotConfig.isPaused || ball == null || car == null) {
            BotConfig.activeMechanicLabel = if (BotConfig.isPaused) "متوقف" else "بحث..."
            return BotAction(0f, 0f, jump = false, boost = false)
        }

        val dt = ((nowMs - prevTimeMs).coerceIn(1L, 150L)) / 1000f
        if (prevBall != null) {
            val rawVx = (ball.x - prevBall!!.x) / dt
            val rawVy = (ball.y - prevBall!!.y) / dt
            smoothVx = smoothVx * 0.55f + rawVx * 0.45f
            smoothVy = smoothVy * 0.55f + rawVy * 0.45f
        }
        prevBall = ball
        prevTimeMs = nowMs

        val floorY = screenH * 0.85f
        val isGrounded = car.y >= floorY - 30f
        if (isGrounded) {
            jumpCount = 0
        }

        val attackingRight = BotConfig.attackingRight
        val attackDir = if (attackingRight) 1f else -1f
        val ownGoalX = if (attackingRight) screenW * 0.08f else screenW * 0.92f
        val enemyGoalX = if (attackingRight) screenW * 0.92f else screenW * 0.08f

        val distToBall = hypot(ball.x - car.x, ball.y - car.y)
        val ballSpeed = hypot(smoothVx, smoothVy)
        val ballHeightAboveFloor = floorY - ball.y

        // 1. إدارة الحالات النشطة للميكانيكيات الاحترافية
        updateMechanicTransitions(
            ball = ball,
            car = car,
            screenW = screenW,
            screenH = screenH,
            floorY = floorY,
            isGrounded = isGrounded,
            distToBall = distToBall,
            ballSpeed = ballSpeed,
            ballHeightAboveFloor = ballHeightAboveFloor,
            attackDir = attackDir,
            ownGoalX = ownGoalX,
            enemyGoalX = enemyGoalX,
            nowMs = nowMs
        )

        // 2. تنفيذ الميكانيكية المختارة بدقة
        return when (mechanicState) {
            MechanicState.FAST_KICKOFF -> executeFastKickoff(ball, car, screenW, attackDir, nowMs)
            MechanicState.SPIN_360 -> executeSpin360(ball, car, screenW, attackDir, nowMs)
            MechanicState.GOLD_SHOT -> executeGoldShot(ball, car, screenW, attackDir, nowMs)
            MechanicState.PURPLE_SHOT -> executePurpleShot(ball, car, screenW, attackDir, nowMs)
            MechanicState.STALL_RESET -> executeStallReset(ball, car, screenW, attackDir, nowMs)
            MechanicState.SHADOW_DEFENSE -> executeShadowDefense(ball, car, screenW, screenH, floorY, ownGoalX, attackDir, nowMs)
            MechanicState.NORMAL -> executeNormalPlay(ball, car, screenW, screenH, floorY, ownGoalX, attackDir, nowMs)
        }
    }

    private fun updateMechanicTransitions(
        ball: Point2D,
        car: Point2D,
        screenW: Int,
        screenH: Int,
        floorY: Float,
        isGrounded: Boolean,
        distToBall: Float,
        ballSpeed: Float,
        ballHeightAboveFloor: Float,
        attackDir: Float,
        ownGoalX: Float,
        enemyGoalX: Float,
        nowMs: Long
    ) {
        val elapsed = nowMs - mechanicStartMs
        val cooldownOk = (nowMs - lastMechanicEndMs) > 420L

        // إنهاء الحركات المؤقتة عند اكتمال مدتها
        when (mechanicState) {
            MechanicState.SPIN_360 -> {
                if (elapsed > 340L || distToBall > screenW * 0.42f) {
                    finishMechanic(nowMs)
                } else {
                    return
                }
            }
            MechanicState.GOLD_SHOT,
            MechanicState.PURPLE_SHOT,
            MechanicState.STALL_RESET -> {
                if (elapsed > 260L || distToBall > screenW * 0.25f) {
                    finishMechanic(nowMs)
                } else {
                    return
                }
            }
            MechanicState.FAST_KICKOFF -> {
                if (elapsed > 1100L || distToBall < screenW * 0.065f || ballSpeed > 450f) {
                    finishMechanic(nowMs)
                } else {
                    return
                }
            }
            else -> {}
        }

        // أ) كشف ضربة البداية السريعة (Fast Kickoff): الكرة ثابتة في منتصف الملعب
        val ballAtCenter = abs(ball.x - screenW * 0.5f) < screenW * 0.045f &&
            ball.y in (screenH * 0.62f)..(screenH * 0.84f)
        if (ballAtCenter && ballSpeed < 65f && distToBall > screenW * 0.14f) {
            startMechanic(MechanicState.FAST_KICKOFF, nowMs)
            return
        }

        // ب) كشف الخطر الدفاعي (Shadow Defense): الكرة تتجه نحو مرمانا الأيمن بسرعة
        val headingToOwnGoal = if (attackDir < 0f) smoothVx > 210f else smoothVx < -210f
        val inDefensiveHalf = abs(ball.x - ownGoalX) < screenW * 0.38f
        if (headingToOwnGoal && inDefensiveHalf) {
            mechanicState = MechanicState.SHADOW_DEFENSE
            return
        }

        if (!cooldownOk) {
            mechanicState = MechanicState.NORMAL
            return
        }

        val style = BotConfig.proPlayStyle
        val carBehindBall = (ball.x - car.x) * attackDir > -20f
        val nearEnemyGoal = abs(ball.x - enemyGoalX) < screenW * 0.42f

        // ج) حركة 360° الهوائية (360 Spin Shot): الكرة مرتفعة والسيارة في وضعية هجوم جوي
        val canDo360 = (style == ProPlayStyle.FOCUS_360 || style == ProPlayStyle.AUTO_SMART)
        if (canDo360 &&
            ballHeightAboveFloor > screenH * 0.16f &&
            distToBall in (screenW * 0.13f)..(screenW * 0.34f) &&
            carBehindBall
        ) {
            spinDirection = if (attackDir < 0f) -1f else 1f
            lastSpinAngle = if (attackDir < 0f) PI.toFloat() else 0f
            startMechanic(MechanicState.SPIN_360, nowMs)
            return
        }

        // د) Stall / Flip Reset: السيارة أسفل الكرة مباشرة في الهواء لإعادة شحن القفزة
        if (style == ProPlayStyle.AUTO_SMART &&
            !isGrounded &&
            jumpCount >= 1 &&
            ballHeightAboveFloor > screenH * 0.24f &&
            abs(ball.x - car.x) < screenW * 0.055f &&
            (car.y - ball.y) in (screenH * 0.03f)..(screenH * 0.11f)
        ) {
            startMechanic(MechanicState.STALL_RESET, nowMs)
            return
        }

        // هـ) التسديدة البنفسجية (Purple Shot): الكرة أعلى السيارة بقليل وعلى مسافة قريبة
        val canDoShots = (style == ProPlayStyle.GOLD_AND_PURPLE || style == ProPlayStyle.AUTO_SMART)
        if (canDoShots &&
            distToBall < screenW * 0.13f &&
            (car.y - ball.y) in (screenH * 0.04f)..(screenH * 0.12f) &&
            carBehindBall
        ) {
            startMechanic(MechanicState.PURPLE_SHOT, nowMs)
            return
        }

        // و) التسديدة الذهبية (Gold Shot): السيارة في زاوية مثالية لتوجيه ظهرها للكرة وإطلاق تسديدة صاروخية
        if (canDoShots &&
            distToBall < screenW * 0.14f &&
            carBehindBall &&
            (nearEnemyGoal || style == ProPlayStyle.GOLD_AND_PURPLE)
        ) {
            startMechanic(MechanicState.GOLD_SHOT, nowMs)
            return
        }

        mechanicState = MechanicState.NORMAL
    }

    private fun startMechanic(state: MechanicState, nowMs: Long) {
        mechanicState = state
        mechanicStartMs = nowMs
    }

    private fun finishMechanic(nowMs: Long) {
        mechanicState = MechanicState.NORMAL
        lastMechanicEndMs = nowMs
    }

    // 1. ضربة البداية السريعة (Fast Kickoff)
    private fun executeFastKickoff(
        ball: Point2D,
        car: Point2D,
        screenW: Int,
        attackDir: Float,
        nowMs: Long
    ): BotAction {
        BotConfig.activeMechanicLabel = "Fast Kickoff ⚡"
        val dist = abs(ball.x - car.x)
        val canJump = (nowMs - lastJumpTimeMs) > 180L
        var jump = false

        if (canJump) {
            if (jumpCount == 0 && dist < screenW * 0.26f) {
                jump = true
                jumpCount = 1
                lastJumpTimeMs = nowMs
            } else if (jumpCount == 1 && dist < screenW * 0.095f) {
                jump = true
                jumpCount = 2
                lastJumpTimeMs = nowMs
            }
        }

        return BotAction(
            stickX = attackDir,
            stickY = -0.18f, // زاوية منخفضة لزيادة السرعة الأفقية
            jump = jump,
            boost = true
        )
    }

    // 2. حركة 360° الكاملة والدقيقة (360 Spin + Power Finish)
    private fun executeSpin360(
        ball: Point2D,
        car: Point2D,
        screenW: Int,
        attackDir: Float,
        nowMs: Long
    ): BotAction {
        BotConfig.activeMechanicLabel = "حركة 360° 🌀"
        val elapsed = (nowMs - mechanicStartMs).coerceAtLeast(0L)
        val spinDurationMs = 260f

        // القفز أولاً لرفع السيارة في الهواء إذا لم تكن قد قفزت
        var jump = false
        if (jumpCount == 0 && (nowMs - lastJumpTimeMs) > 150L) {
            jump = true
            jumpCount = 1
            lastJumpTimeMs = nowMs
        }

        if (elapsed <= spinDurationMs) {
            val progress = (elapsed / spinDurationMs).coerceIn(0f, 1f)
            val baseAngle = if (attackDir < 0f) PI.toFloat() else 0f
            val currentAngle = baseAngle + spinDirection * (2f * PI.toFloat() * progress)
            val deltaSweep = currentAngle - lastSpinAngle
            lastSpinAngle = currentAngle

            return BotAction(
                stickX = cos(currentAngle).coerceIn(-1f, 1f),
                stickY = sin(currentAngle).coerceIn(-1f, 1f),
                jump = jump,
                boost = progress < 0.35f || progress > 0.75f,
                sweepArcRad = deltaSweep
            )
        } else {
            // فور اكتمال الـ 360 درجة: تسديدة قوية مباشرة نحو الكرة
            val dx = ball.x - car.x
            val dy = ball.y - car.y
            val dist = hypot(dx, dy)
            val angle = atan2(dy, dx)

            if (jumpCount == 1 && dist < screenW * 0.11f && (nowMs - lastJumpTimeMs) > 180L) {
                jump = true
                jumpCount = 2
                lastJumpTimeMs = nowMs
            }

            return BotAction(
                stickX = cos(angle).coerceIn(-1f, 1f),
                stickY = sin(angle).coerceIn(-1f, 1f),
                jump = jump,
                boost = true
            )
        }
    }

    // 3. التسديدة الذهبية (Gold Shot - ضرب الكرة بظهر السيارة مع Dodge عكسي)
    private fun executeGoldShot(
        ball: Point2D,
        car: Point2D,
        screenW: Int,
        attackDir: Float,
        nowMs: Long
    ): BotAction {
        BotConfig.activeMechanicLabel = "Gold Shot 🟡"
        val dist = hypot(ball.x - car.x, ball.y - car.y)
        val elapsed = nowMs - mechanicStartMs

        // المرحلة 1 (0..110ms): توجيه مقدمة السيارة عكس المرمى ليصبح ظهرها مواجهاً للكرة
        // المرحلة 2 (110..260ms): تنفيذ القفزة الثانية بالاتجاه المعاكس لحظة التلامس
        var jump = false
        if (elapsed >= 95L && dist < screenW * 0.095f && (nowMs - lastJumpTimeMs) > 170L) {
            jump = true
            jumpCount = 2
            lastJumpTimeMs = nowMs
        }

        // -attackDir تعني توجيه العصا عكس اتجاه الهجوم لتدوير السيارة 180 درجة وضربها بالظهر
        return BotAction(
            stickX = -attackDir,
            stickY = -0.15f,
            jump = jump,
            boost = elapsed < 80L
        )
    }

    // 4. التسديدة البنفسجية (Purple Shot - ضرب الكرة ببطن/عجلات السيارة مع تحرير العصا)
    private fun executePurpleShot(
        ball: Point2D,
        car: Point2D,
        screenW: Int,
        attackDir: Float,
        nowMs: Long
    ): BotAction {
        BotConfig.activeMechanicLabel = "Purple Shot 🟣"
        val dist = hypot(ball.x - car.x, ball.y - car.y)
        val elapsed = nowMs - mechanicStartMs

        if (elapsed < 95L) {
            // إمالة السيارة 90 درجة للأعلى ليواجه بطنها الكرة
            return BotAction(
                stickX = attackDir * 0.2f,
                stickY = -1.0f,
                jump = false,
                boost = true
            )
        } else {
            // لحظة التلامس: عصا محايدة تماماً + قفزة لإطلاق Purple Shot
            val shouldPop = dist < screenW * 0.095f && (nowMs - lastJumpTimeMs) > 170L
            if (shouldPop) {
                jumpCount = 2
                lastJumpTimeMs = nowMs
            }
            return BotAction(
                stickX = 0f,
                stickY = 0f,
                jump = shouldPop,
                boost = false,
                neutralStick = true
            )
        }
    }

    // 5. حركة Stall لإعادة شحن القفزة في الهواء (Flip Reset)
    private fun executeStallReset(
        ball: Point2D,
        car: Point2D,
        screenW: Int,
        attackDir: Float,
        nowMs: Long
    ): BotAction {
        BotConfig.activeMechanicLabel = "Stall Reset 🔄"
        val elapsed = nowMs - mechanicStartMs
        val dist = hypot(ball.x - car.x, ball.y - car.y)

        if (elapsed < 120L) {
            // تحرير العصا بالكامل وضغط القفز لتثبيت السيارة تحت الكرة وإعادة شحن القفزة
            val tapStall = dist < screenW * 0.11f && (nowMs - lastJumpTimeMs) > 160L
            if (tapStall) {
                lastJumpTimeMs = nowMs
                jumpCount = 0 // تم تجديد القفزة!
            }
            return BotAction(
                stickX = 0f,
                stickY = 0f,
                jump = tapStall,
                boost = false,
                neutralStick = true
            )
        } else {
            // تسديد مباشر بعد تجديد القفزة
            val angle = atan2(ball.y - car.y, (ball.x + attackDir * 20f) - car.x)
            val followUpJump = (nowMs - lastJumpTimeMs) > 160L
            if (followUpJump) {
                lastJumpTimeMs = nowMs
                jumpCount = 1
            }
            return BotAction(
                stickX = cos(angle).coerceIn(-1f, 1f),
                stickY = sin(angle).coerceIn(-1f, 1f),
                jump = followUpJump,
                boost = true
            )
        }
    }

    // 6. الدفاع الذكي (Shadow Defense)
    private fun executeShadowDefense(
        ball: Point2D,
        car: Point2D,
        screenW: Int,
        screenH: Int,
        floorY: Float,
        ownGoalX: Float,
        attackDir: Float,
        nowMs: Long
    ): BotAction {
        BotConfig.activeMechanicLabel = "Shadow Defense 🛡️"
        val predicted = predictBallPosition(ball, smoothVx, smoothVy, 0.30f, screenW.toFloat(), floorY)
        // التموضع بين الكرة ومرمانا الأيمن
        val interceptX = (predicted.x + ownGoalX) * 0.5f
        val dx = interceptX - car.x
        val dy = predicted.y - car.y
        val angle = atan2(dy, dx)

        val distToBall = hypot(ball.x - car.x, ball.y - car.y)
        val canJump = (nowMs - lastJumpTimeMs) > 200L
        var jump = false

        if (canJump && distToBall < screenW * 0.16f) {
            if (jumpCount == 0 && ball.y < floorY - screenH * 0.10f) {
                jump = true
                jumpCount = 1
                lastJumpTimeMs = nowMs
            } else if (jumpCount == 1 && distToBall < screenW * 0.085f) {
                // تشتيت الكرة بقوة نحو مرمى الخصم
                jump = true
                jumpCount = 2
                lastJumpTimeMs = nowMs
                return BotAction(stickX = attackDir, stickY = -0.35f, jump = true, boost = true)
            }
        }

        return BotAction(
            stickX = cos(angle).coerceIn(-1f, 1f),
            stickY = sin(angle).coerceIn(-1f, 1f),
            jump = jump,
            boost = hypot(dx, dy) > screenW * 0.09f
        )
    }

    // 7. اللعب الهجومي والتمركزي الذكي
    private fun executeNormalPlay(
        ball: Point2D,
        car: Point2D,
        screenW: Int,
        screenH: Int,
        floorY: Float,
        ownGoalX: Float,
        attackDir: Float,
        nowMs: Long
    ): BotAction {
        BotConfig.activeMechanicLabel = "هجوم ذكي ⚔️"
        val predicted = predictBallPosition(ball, smoothVx, smoothVy, 0.32f, screenW.toFloat(), floorY)

        // التموضع خلف الكرة من جهة مرمانا لدفعها نحو مرمى الخصم
        val behindOffset = -attackDir * 48f
        val targetX = (predicted.x + behindOffset).coerceIn(45f, screenW - 45f)
        val targetY = predicted.y

        val dx = targetX - car.x
        val dy = targetY - car.y
        val distToTarget = hypot(dx, dy)
        val angle = atan2(dy, dx)

        val distToBall = hypot(ball.x - car.x, ball.y - car.y)
        val ballIsHigh = ball.y < floorY - (screenH * 0.13f)
        val canJump = (nowMs - lastJumpTimeMs) > 200L
        var jump = false

        if (canJump) {
            if (jumpCount == 0 && ballIsHigh && abs(ball.x - car.x) < screenW * 0.25f) {
                jump = true
                jumpCount = 1
                lastJumpTimeMs = nowMs
            } else if (jumpCount == 1 && distToBall < screenW * 0.09f) {
                jump = true
                jumpCount = 2
                lastJumpTimeMs = nowMs
            }
        }

        return BotAction(
            stickX = cos(angle).coerceIn(-1f, 1f),
            stickY = sin(angle).coerceIn(-1f, 1f),
            jump = jump,
            boost = distToTarget > screenW * 0.11f
        )
    }

    private fun predictBallPosition(
        pos: Point2D,
        vx: Float,
        vy: Float,
        lookAheadSec: Float,
        maxW: Float,
        floorY: Float
    ): Point2D {
        val gravity = 980f
        var predX = pos.x + vx * lookAheadSec
        var predY = pos.y + vy * lookAheadSec + 0.5f * gravity * lookAheadSec * lookAheadSec

        if (predX < 40f) predX = 40f + (40f - predX) * 0.8f
        if (predX > maxW - 40f) predX = (maxW - 40f) - (predX - (maxW - 40f)) * 0.8f
        if (predY > floorY) predY = floorY - (predY - floorY) * 0.75f
        if (predY < 50f) predY = 50f + (50f - predY) * 0.75f

        return Point2D(predX, predY)
    }
}
