package com.ai.sideswipebot

enum class TeamColor {
    BLUE,
    ORANGE
}

enum class TeamDetectMode {
    AUTO,
    FORCE_BLUE,
    FORCE_ORANGE
}

enum class ProPlayStyle {
    AUTO_SMART,      // يختار تلقائياً أفضل حركة (360 / Gold / Purple / Stall / Kickoff)
    FOCUS_360,       // يركز على تنفيذ حركات 360° الهوائية والتسديد بعدها
    GOLD_AND_PURPLE  // يركز على التسديدات الذهبية والبنفسجية الصاروخية
}

object BotConfig {
    // افتراضياً: مرمى فريقك على اليمين والهجوم نحو اليسار (attackingRight = false)
    @Volatile
    var attackingRight: Boolean = false

    @Volatile
    var isPaused: Boolean = false

    @Volatile
    var currentTeam: TeamColor = TeamColor.BLUE

    @Volatile
    var teamDetectMode: TeamDetectMode = TeamDetectMode.AUTO

    @Volatile
    var proPlayStyle: ProPlayStyle = ProPlayStyle.AUTO_SMART

    @Volatile
    var activeMechanicLabel: String = "استعداد"
}
