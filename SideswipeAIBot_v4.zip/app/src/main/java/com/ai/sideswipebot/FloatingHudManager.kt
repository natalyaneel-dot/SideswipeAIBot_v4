package com.ai.sideswipebot

import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class FloatingHudManager(private val context: Context) {

    private var windowManager: WindowManager? = null
    private var rootView: LinearLayout? = null
    private var statusText: TextView? = null
    private val mainHandler = Handler(Looper.getMainLooper())

    fun show() {
        if (!Settings.canDrawOverlays(context)) return
        if (rootView != null) return

        windowManager = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager

        val container = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(18, 8, 18, 8)
            background = GradientDrawable().apply {
                setColor(Color.argb(215, 16, 20, 30))
                cornerRadius = 24f
                setStroke(2, Color.argb(200, 255, 195, 0))
            }
        }

        val info = TextView(context).apply {
            text = "فريق: أزرق | استعداد"
            setTextColor(Color.WHITE)
            textSize = 11f
            setPadding(0, 0, 12, 0)
        }

        val styleBtn = Button(context).apply {
            text = "أسلوب: شامل"
            textSize = 10f
            setPadding(10, 2, 10, 2)
            setOnClickListener {
                BotConfig.proPlayStyle = when (BotConfig.proPlayStyle) {
                    ProPlayStyle.AUTO_SMART -> ProPlayStyle.FOCUS_360
                    ProPlayStyle.FOCUS_360 -> ProPlayStyle.GOLD_AND_PURPLE
                    ProPlayStyle.GOLD_AND_PURPLE -> ProPlayStyle.AUTO_SMART
                }
                text = when (BotConfig.proPlayStyle) {
                    ProPlayStyle.AUTO_SMART -> "أسلوب: شامل"
                    ProPlayStyle.FOCUS_360 -> "تركيز: 360° 🌀"
                    ProPlayStyle.GOLD_AND_PURPLE -> "ذهبية/بنفسجية"
                }
            }
        }

        val colorSwitchBtn = Button(context).apply {
            text = "لون: تلقائي"
            textSize = 10f
            setPadding(10, 2, 10, 2)
            setOnClickListener {
                BotConfig.teamDetectMode = when (BotConfig.teamDetectMode) {
                    TeamDetectMode.AUTO -> TeamDetectMode.FORCE_BLUE
                    TeamDetectMode.FORCE_BLUE -> TeamDetectMode.FORCE_ORANGE
                    TeamDetectMode.FORCE_ORANGE -> TeamDetectMode.AUTO
                }
                text = when (BotConfig.teamDetectMode) {
                    TeamDetectMode.AUTO -> "لون: تلقائي"
                    TeamDetectMode.FORCE_BLUE -> "أزرق 🔵"
                    TeamDetectMode.FORCE_ORANGE -> "برتقالي 🟠"
                }
            }
        }

        val pauseBtn = Button(context).apply {
            text = "إيقاف"
            textSize = 10f
            setPadding(10, 2, 10, 2)
            setOnClickListener {
                BotConfig.isPaused = !BotConfig.isPaused
                text = if (BotConfig.isPaused) "تشغيل" else "إيقاف"
            }
        }

        container.addView(info)
        container.addView(styleBtn)
        container.addView(colorSwitchBtn)
        container.addView(pauseBtn)

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 18
            y = 14
        }

        windowManager?.addView(container, params)
        rootView = container
        statusText = info
    }

    fun updateStatus(team: TeamColor, hasBall: Boolean, hasCar: Boolean) {
        val view = statusText ?: return
        mainHandler.post {
            val teamLabel = if (team == TeamColor.BLUE) "🔵" else "🟠"
            val visionMark = if (hasBall && hasCar) "✓" else "!"
            view.text = "$teamLabel [$visionMark] ${BotConfig.activeMechanicLabel}"
        }
    }

    fun hide() {
        val view = rootView ?: return
        mainHandler.post {
            try {
                windowManager?.removeView(view)
            } catch (_: Exception) {
            }
            rootView = null
            statusText = null
        }
    }
}
