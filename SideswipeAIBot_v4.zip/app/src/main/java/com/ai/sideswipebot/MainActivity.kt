package com.ai.sideswipebot

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private val captureLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK && result.data != null) {
            BotConfig.isPaused = false
            val serviceIntent = Intent(this, ScreenCaptureService::class.java).apply {
                putExtra("RESULT_CODE", result.resultCode)
                putExtra("DATA", result.data)
            }
            startForegroundService(serviceIntent)
            Toast.makeText(this, "تم تشغيل البوت الاحترافي! افتح اللعبة الآن", Toast.LENGTH_LONG).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(44, 60, 44, 44)
        }

        val title = TextView(this).apply {
            text = "Sideswipe Pro AI Bot v4.0"
            textSize = 23f
            setPadding(0, 0, 0, 10)
        }

        val subtitle = TextView(this).apply {
            text = "ميكانيكيات المحترفين: 360° Spin • Gold Shot • Purple Shot • Stall Reset • Fast Kickoff"
            textSize = 13f
            setPadding(0, 0, 0, 20)
        }

        val directionSwitch = Switch(this).apply {
            text = "مرمى فريقي على اليمين (الهجوم نحو اليسار)"
            isChecked = !BotConfig.attackingRight
            setPadding(0, 0, 0, 20)
            setOnCheckedChangeListener { _, isGoalRight ->
                BotConfig.attackingRight = !isGoalRight
            }
        }

        val styleLabel = TextView(this).apply {
            text = "اختر أسلوب اللعب الاحترافي:"
            textSize = 14f
            setPadding(0, 0, 0, 8)
        }

        val styleGroup = RadioGroup(this).apply {
            orientation = RadioGroup.VERTICAL
            setPadding(0, 0, 0, 20)

            val rbSmart = RadioButton(this@MainActivity).apply {
                id = 1
                text = "شامل تلقائي (كل الحركات حسب الموقف)"
                isChecked = BotConfig.proPlayStyle == ProPlayStyle.AUTO_SMART
            }
            val rb360 = RadioButton(this@MainActivity).apply {
                id = 2
                text = "تركيز على حركات 360° الهوائية والتسديد"
                isChecked = BotConfig.proPlayStyle == ProPlayStyle.FOCUS_360
            }
            val rbShots = RadioButton(this@MainActivity).apply {
                id = 3
                text = "تركيز على التسديدات الذهبية والبنفسجية"
                isChecked = BotConfig.proPlayStyle == ProPlayStyle.GOLD_AND_PURPLE
            }

            addView(rbSmart)
            addView(rb360)
            addView(rbShots)

            setOnCheckedChangeListener { _, checkedId ->
                BotConfig.proPlayStyle = when (checkedId) {
                    2 -> ProPlayStyle.FOCUS_360
                    3 -> ProPlayStyle.GOLD_AND_PURPLE
                    else -> ProPlayStyle.AUTO_SMART
                }
            }
        }

        val btnOverlay = Button(this).apply {
            text = "1. تفعيل الشاشة العائمة (لعرض الحركات فوق اللعبة)"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    val intent = Intent(
                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")
                    )
                    startActivity(intent)
                } else {
                    Toast.makeText(this@MainActivity, "الشاشة العائمة مفعلة بالفعل ✓", Toast.LENGTH_SHORT).show()
                }
            }
        }

        val btnAccessibility = Button(this).apply {
            text = "2. تفعيل خدمة التحكم باللمس (Accessibility)"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
        }

        val btnStart = Button(this).apply {
            text = "3. تشغيل البوت الاحترافي"
            setOnClickListener {
                if (BotAccessibilityService.instance == null) {
                    Toast.makeText(this@MainActivity, "فعّل خدمة Accessibility أولاً!", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }
                val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                captureLauncher.launch(manager.createScreenCaptureIntent())
            }
        }

        val btnStop = Button(this).apply {
            text = "4. إيقاف البوت"
            setOnClickListener {
                stopService(Intent(this@MainActivity, ScreenCaptureService::class.java))
                Toast.makeText(this@MainActivity, "تم إيقاف البوت", Toast.LENGTH_SHORT).show()
            }
        }

        layout.addView(title)
        layout.addView(subtitle)
        layout.addView(directionSwitch)
        layout.addView(styleLabel)
        layout.addView(styleGroup)
        layout.addView(btnOverlay)
        layout.addView(btnAccessibility)
        layout.addView(btnStart)
        layout.addView(btnStop)
        setContentView(layout)
    }
}
