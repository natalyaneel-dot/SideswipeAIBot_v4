package com.ai.sideswipebot

import android.app.Activity
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

class ScreenCaptureService : Service() {

    private var mediaProjection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private var workerThread: HandlerThread? = null
    private var workerHandler: Handler? = null

    private val brain = BotBrain()
    private var hudManager: FloatingHudManager? = null
    private var lastProcessMs = 0L

    private var blueVoteScore = 5
    private var lastBallScaled: Point2D? = null
    private var lastCarScaled: Point2D? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForegroundNotification()

        hudManager = FloatingHudManager(this).apply { show() }

        val resultCode = intent?.getIntExtra("RESULT_CODE", Activity.RESULT_CANCELED) ?: return START_NOT_STICKY
        val data: Intent = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            intent.getParcelableExtra("DATA", Intent::class.java)
        } else {
            @Suppress("DEPRECATION")
            intent.getParcelableExtra("DATA")
        } ?: return START_NOT_STICKY

        val metrics = resources.displayMetrics
        val width = metrics.widthPixels / 2
        val height = metrics.heightPixels / 2
        val density = metrics.densityDpi

        workerThread = HandlerThread("BotProVisionThread").apply { start() }
        workerHandler = Handler(workerThread!!.looper)

        val projectionManager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        mediaProjection = projectionManager.getMediaProjection(resultCode, data)

        imageReader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
        virtualDisplay = mediaProjection?.createVirtualDisplay(
            "SideswipeProCapture",
            width,
            height,
            density,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            imageReader?.surface,
            null,
            workerHandler
        )

        imageReader?.setOnImageAvailableListener({ reader ->
            val image = reader.acquireLatestImage() ?: return@setOnImageAvailableListener
            val now = System.currentTimeMillis()
            // سرعة معالجة عالية (~35 إطار/ثانية) لتنفيذ حركات 360 والتسديدات بدقة
            if (now - lastProcessMs < 28L) {
                image.close()
                return@setOnImageAvailableListener
            }
            lastProcessMs = now

            try {
                val plane = image.planes[0]
                val buffer = plane.buffer
                val pixelStride = plane.pixelStride
                val rowStride = plane.rowStride
                val rowPadding = rowStride - pixelStride * width

                val bitmap = Bitmap.createBitmap(
                    width + rowPadding / pixelStride,
                    height,
                    Bitmap.Config.ARGB_8888
                )
                bitmap.copyPixelsFromBuffer(buffer)

                val detectedTeam = when (BotConfig.teamDetectMode) {
                    TeamDetectMode.FORCE_BLUE -> TeamColor.BLUE
                    TeamDetectMode.FORCE_ORANGE -> TeamColor.ORANGE
                    TeamDetectMode.AUTO -> detectMyTeamColor(bitmap, width, height)
                }
                BotConfig.currentTeam = detectedTeam

                val (ballPos, carPos) = detectEntities(bitmap, width, height, detectedTeam)
                bitmap.recycle()

                val realW = metrics.widthPixels
                val realH = metrics.heightPixels
                val scaledBall = ballPos?.let { Point2D(it.x * 2f, it.y * 2f) }
                val scaledCar = carPos?.let { Point2D(it.x * 2f, it.y * 2f) }

                if (scaledBall != null) lastBallScaled = scaledBall
                if (scaledCar != null) lastCarScaled = scaledCar

                hudManager?.updateStatus(detectedTeam, scaledBall != null, scaledCar != null)

                val action = brain.decide(scaledBall, scaledCar, realW, realH, now)
                BotAccessibilityService.instance?.executeAction(action, realW, realH)
            } finally {
                image.close()
            }
        }, workerHandler)

        return START_STICKY
    }

    private fun detectMyTeamColor(bitmap: Bitmap, w: Int, h: Int): TeamColor {
        val startX = if (BotConfig.attackingRight) (w * 0.37f).toInt() else (w * 0.54f).toInt()
        val endX = if (BotConfig.attackingRight) (w * 0.46f).toInt() else (w * 0.63f).toInt()
        val startY = (h * 0.02f).toInt()
        val endY = (h * 0.09f).toInt()

        var bluePixels = 0
        var orangePixels = 0

        for (y in startY until endY step 2) {
            for (x in startX until endX step 2) {
                val pixel = bitmap.getPixel(x, y)
                val r = Color.red(pixel)
                val g = Color.green(pixel)
                val b = Color.blue(pixel)

                if (b > 170 && b > r + 60) {
                    bluePixels++
                } else if (r > 180 && g in 60..175 && r > b + 80) {
                    orangePixels++
                }
            }
        }

        if (bluePixels > orangePixels + 4) {
            blueVoteScore = (blueVoteScore + 1).coerceAtMost(12)
        } else if (orangePixels > bluePixels + 4) {
            blueVoteScore = (blueVoteScore - 1).coerceAtLeast(0)
        }

        return if (blueVoteScore >= 6) TeamColor.BLUE else TeamColor.ORANGE
    }

    private fun detectEntities(
        bitmap: Bitmap,
        w: Int,
        h: Int,
        myTeam: TeamColor
    ): Pair<Point2D?, Point2D?> {
        val ballPoints = ArrayList<Point2D>(64)
        val carPoints = ArrayList<Point2D>(64)

        val step = 3
        val minY = (h * 0.13f).toInt()
        val maxY = (h * 0.87f).toInt()
        val minX = (w * 0.04f).toInt()
        val maxX = (w * 0.96f).toInt()

        for (y in minY until maxY step step) {
            for (x in minX until maxX step step) {
                val pixel = bitmap.getPixel(x, y)
                val r = Color.red(pixel)
                val g = Color.green(pixel)
                val b = Color.blue(pixel)

                val maxC = max(r, max(g, b))
                val minC = min(r, min(g, b))

                if (minC > 212 && (maxC - minC) < 35) {
                    ballPoints.add(Point2D(x.toFloat(), y.toFloat()))
                } else if (myTeam == TeamColor.BLUE) {
                    if (b > 210 && g in 120..225 && r < 90) {
                        carPoints.add(Point2D(x.toFloat(), y.toFloat()))
                    }
                } else {
                    if (r > 215 && g in 85..175 && b < 68) {
                        carPoints.add(Point2D(x.toFloat(), y.toFloat()))
                    }
                }
            }
        }

        val ball = computeBestCluster(ballPoints, lastBallScaled?.let { Point2D(it.x / 2f, it.y / 2f) }, 4)
        val rawCar = computeBestCluster(carPoints, lastCarScaled?.let { Point2D(it.x / 2f, it.y / 2f) }, 3)
        val car = rawCar?.let { Point2D(it.x, it.y + 24f) }

        return Pair(ball, car)
    }

    private fun computeBestCluster(
        points: List<Point2D>,
        prevPos: Point2D?,
        minPoints: Int
    ): Point2D? {
        if (points.size < minPoints) return null

        if (prevPos != null) {
            val nearPoints = points.filter { hypot(it.x - prevPos.x, it.y - prevPos.y) < 95f }
            if (nearPoints.size >= minPoints) {
                var sx = 0f
                var sy = 0f
                for (p in nearPoints) {
                    sx += p.x
                    sy += p.y
                }
                return Point2D(sx / nearPoints.size, sy / nearPoints.size)
            }
        }

        var sx = 0f
        var sy = 0f
        for (p in points) {
            sx += p.x
            sy += p.y
        }
        return Point2D(sx / points.size, sy / points.size)
    }

    private fun startForegroundNotification() {
        val channelId = "sideswipe_bot_channel"
        val manager = getSystemService(NotificationManager::class.java)
        val channel = NotificationChannel(channelId, "Sideswipe Pro AI Bot", NotificationManager.IMPORTANCE_LOW)
        manager.createNotificationChannel(channel)

        val notification = Notification.Builder(this, channelId)
            .setContentTitle("Sideswipe Pro AI Bot v4.0")
            .setContentText("ميكانيكيات المحترفين مفعلة (360° / Gold / Purple / Stall)")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .build()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(1, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(1, notification)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        hudManager?.hide()
        virtualDisplay?.release()
        imageReader?.close()
        mediaProjection?.stop()
        workerThread?.quitSafely()
    }
}
