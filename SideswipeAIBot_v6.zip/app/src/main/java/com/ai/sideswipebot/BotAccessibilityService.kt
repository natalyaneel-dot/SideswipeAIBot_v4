package com.ai.sideswipebot

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.view.accessibility.AccessibilityEvent
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.sin

class BotAccessibilityService : AccessibilityService() {

    companion object {
        var instance: BotAccessibilityService? = null
    }

    private val isGestureDispatching = AtomicBoolean(false)
    private var lastGestureFinishedMs: Long = 0L

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val pkg = event?.packageName?.toString() ?: return
        if (pkg.isNotBlank() && pkg != "android" && pkg != "com.android.systemui") {
            BotConfig.currentForegroundPackage = pkg
            if (BotConfig.onlyTouchInsideGame &&
                pkg != BotConfig.GAME_PACKAGE_NAME &&
                pkg != packageName &&
                !BotConfig.isPaused
            ) {
                BotConfig.isPaused = true
                BotConfig.activeMechanicLabel = "متوقف (خارج اللعبة)"
                FloatingHudManager.refreshButtonsFromAnywhere()
            }
        }
    }

    override fun onInterrupt() {
        instance = null
    }

    override fun onDestroy() {
        super.onDestroy()
        instance = null
    }

    fun executeAction(action: BotAction, screenW: Int, screenH: Int) {
        if (BotConfig.isPaused || BotConfig.isLearningMode) return

        if (BotConfig.onlyTouchInsideGame) {
            val fg = BotConfig.currentForegroundPackage
            if (fg != BotConfig.GAME_PACKAGE_NAME) {
                return
            }
        }

        val now = System.currentTimeMillis()
        if (isGestureDispatching.get() || (now - lastGestureFinishedMs) < 22L) {
            return
        }

        val builder = GestureDescription.Builder()
        var hasStroke = false
        val hudRect = BotConfig.hudBoundsOnScreen

        val magnitude = hypot(action.stickX, action.stickY)
        if (!action.neutralStick && magnitude >= 0.05f) {
            val stickCenterX = screenW * 0.16f
            val stickCenterY = screenH * 0.74f
            val stickRadius = screenH * 0.12f

            val endX = (stickCenterX + action.stickX * stickRadius).coerceIn(12f, screenW - 12f)
            val endY = (stickCenterY + action.stickY * stickRadius).coerceIn(12f, screenH - 12f)

            if (!hudRect.contains(stickCenterX.toInt(), stickCenterY.toInt())) {
                val stickPath = Path()
                if (abs(action.sweepArcRad) > 0.05f) {
                    val endAngle = atan2(action.stickY, action.stickX)
                    val startAngle = endAngle - action.sweepArcRad
                    val midAngle = startAngle + action.sweepArcRad * 0.5f

                    val sx = (stickCenterX + cos(startAngle) * stickRadius).coerceIn(12f, screenW - 12f)
                    val sy = (stickCenterY + sin(startAngle) * stickRadius).coerceIn(12f, screenH - 12f)
                    val mx = (stickCenterX + cos(midAngle) * stickRadius).coerceIn(12f, screenW - 12f)
                    val my = (stickCenterY + sin(midAngle) * stickRadius).coerceIn(12f, screenH - 12f)

                    stickPath.moveTo(sx, sy)
                    stickPath.quadTo(mx, my, endX, endY)
                } else {
                    stickPath.moveTo(stickCenterX, stickCenterY)
                    stickPath.lineTo(endX, endY)
                }

                builder.addStroke(GestureDescription.StrokeDescription(stickPath, 0L, 36L))
                hasStroke = true
            }
        }

        if (action.jump) {
            val jumpX = screenW * 0.88f
            val jumpY = screenH * 0.76f
            if (!hudRect.contains(jumpX.toInt(), jumpY.toInt())) {
                val jumpPath = Path().apply {
                    moveTo(jumpX, jumpY)
                    lineTo(jumpX + 2f, jumpY + 2f)
                }
                builder.addStroke(GestureDescription.StrokeDescription(jumpPath, 0L, 30L))
                hasStroke = true
            }
        }

        if (action.boost) {
            val boostX = screenW * 0.77f
            val boostY = screenH * 0.80f
            if (!hudRect.contains(boostX.toInt(), boostY.toInt())) {
                val boostPath = Path().apply {
                    moveTo(boostX, boostY)
                    lineTo(boostX + 2f, boostY + 2f)
                }
                builder.addStroke(GestureDescription.StrokeDescription(boostPath, 0L, 36L))
                hasStroke = true
            }
        }

        if (!hasStroke) return

        isGestureDispatching.set(true)
        val dispatched = dispatchGesture(
            builder.build(),
            object : GestureResultCallback() {
                override fun onCompleted(gestureDescription: GestureDescription?) {
                    lastGestureFinishedMs = System.currentTimeMillis()
                    isGestureDispatching.set(false)
                }

                override fun onCancelled(gestureDescription: GestureDescription?) {
                    lastGestureFinishedMs = System.currentTimeMillis()
                    isGestureDispatching.set(false)
                }
            },
            null
        )

        if (!dispatched) {
            isGestureDispatching.set(false)
        }
    }
}
