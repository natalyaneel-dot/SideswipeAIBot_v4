package com.ai.sideswipebot

import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.sin

data class Point2D(val x: Float, val y: Float)

data class BotAction(
    val stickX: Float,
    val stickY: Float,
    val jump: Boolean,
    val boost: Boolean,
    val neutralStick: Boolean = false,
    val sweepArcRad: Float = 0f
)

private enum class MechanicState {
    NORMAL,
    FAST_KICKOFF,
    SPIN_360,
    GOLD_SHOT,
    PURPLE_SHOT,
    STALL_RESET,
    SHADOW_DEFENSE
}

class BotBrain(private val learner: ImitationLearner) {
    private var prevBall: Point2D? = null
    private var prevTimeMs: Long = 0L
    private var smoothVx: Float = 0f
    private var smoothVy: Float = 0f

    private var lastJumpTimeMs: Long = 0L
    private var jumpCount: Int = 0

    private var mechanicState: MechanicState = MechanicState.NORMAL
    private var mechanicStartMs: Long = 0L
    private var lastMechanicEndMs: Long = 0L
    private var spinDirection: Float = 1f
    private var lastSpinAngle: Float = 0f

    fun decide(
        ball: Point2D?,
        car: Point2D?,
        screenW: Int,
        screenH: Int,
        nowMs: Long
    ): BotAction? {
        val dt = ((nowMs - prevTimeMs).coerceIn(1L, 150L)) / 1000f
        if (ball != null && prevBall != null) {
            val rawVx = (ball.x - prevBall!!.x) / dt
            val rawVy = (ball.y - prevBall!!.y) / dt
            if (hypot(rawVx, rawVy) < screenW * 3.5f) {
                smoothVx = smoothVx * 0.55f + rawVx * 0.45f
                smoothVy = smoothVy * 0.55f + rawVy * 0.45f
            }
        }
        prevBall = ball
        prevTimeMs = nowMs

        if (BotConfig.isLearningMode) {
            BotConfig.activeMechanicLabel = "يتعلم منك (${BotConfig.learnedSamplesCount})"
            learner.observePlayerFrame(ball, car, smoothVx, smoothVy, screenW, screenH, nowMs)
            return null
        }

        if (BotConfig.isPaused) {
            BotConfig.activeMechanicLabel = "متوقف (اضغط تشغيل)"
            return null
        }

        if (ball == null || car == null) {
            BotConfig.activeMechanicLabel = "يبحث عن الكرة/السيارة..."
            return null
        }

        val floorY = screenH * 0.85f
        val isGrounded = car.y >= floorY - 30f
        if (isGrounded) {
            jumpCount = 0
        }

        val attackingRight = BotConfig.attackingRight
        val attackDir = if (attackingRight) 1f else -1f
        val ownGoalX = if (attackingRight) screenW * 0.08f else screenW * 0.92f
        val enemyGoalX = if (attackingRight) screenW * 0.92f else screenW * 0.08f

        val distToBall = hypot(ball.x - car.x, ball.y - car.y)
        val ballSpeed = hypot(smoothVx, smoothVy)
        val ballHeightAboveFloor = floorY - ball.y

        updateMechanicTransitions(
            ball = ball,
            car = car,
            screenW = screenW,
            screenH = screenH,
            floorY = floorY,
            isGrounded = isGrounded,
            distToBall = distToBall,
            ballSpeed = ballSpeed,
            ballHeightAboveFloor = ballHeightAboveFloor,
            attackDir = attackDir,
            ownGoalX = ownGoalX,
            enemyGoalX = enemyGoalX,
            nowMs = nowMs
        )

        val physicsAction = when (mechanicState) {
            MechanicState.FAST_KICKOFF -> executeFastKickoff(ball, car, screenW, attackDir, nowMs)
            MechanicState.SPIN_360 -> executeSpin360(ball, car, screenW, attackDir, nowMs)
            MechanicState.GOLD_SHOT -> executeGoldShot(ball, car, screenW, attackDir, nowMs)
            MechanicState.PURPLE_SHOT -> executePurpleShot(ball, car, screenW, attackDir, nowMs)
            MechanicState.STALL_RESET -> executeStallReset(ball, car, screenW, attackDir, nowMs)
            MechanicState.SHADOW_DEFENSE -> executeShadowDefense(ball, car, screenW, screenH, floorY, ownGoalX, attackDir, nowMs)
            MechanicState.NORMAL -> executeNormalPlay(ball, car, screenW, screenH, floorY, attackDir, nowMs)
        }

        if (mechanicState == MechanicState.NORMAL) {
            val learned = learner.queryLearnedPolicy(ball, car, smoothVx, smoothVy, screenW, screenH)
            if (learned != null) {
                BotConfig.activeMechanicLabel = "ذكاء متعلّم + هجوم 🧠"
                val blendedX = (learned.stickX * 0.65f + physicsAction.stickX * 0.35f).coerceIn(-1f, 1f)
                val blendedY = (learned.stickY * 0.65f + physicsAction.stickY * 0.35f).coerceIn(-1f, 1f)
                val canJump = (nowMs - lastJumpTimeMs) > 210L
                val finalJump = if (canJump && (learned.jump || physicsAction.jump) && jumpCount < 2) {
                    jumpCount++
                    lastJumpTimeMs = nowMs
                    true
                } else {
                    physicsAction.jump
                }
                return BotAction(
                    stickX = blendedX,
                    stickY = blendedY,
                    jump = finalJump,
                    boost = learned.boost || physicsAction.boost
                )
            }
        }

        return physicsAction
    }

    private fun updateMechanicTransitions(
        ball: Point2D,
        car: Point2D,
        screenW: Int,
        screenH: Int,
        floorY: Float,
        isGrounded: Boolean,
        distToBall: Float,
        ballSpeed: Float,
        ballHeightAboveFloor: Float,
        attackDir: Float,
        ownGoalX: Float,
        enemyGoalX: Float,
        nowMs: Long
    ) {
        val elapsed = nowMs - mechanicStartMs
        val cooldownOk = (nowMs - lastMechanicEndMs) > 450L

        when (mechanicState) {
            MechanicState.SPIN_360 -> {
                if (elapsed > 340L || distToBall > screenW * 0.42f) finishMechanic(nowMs) else return
            }
            MechanicState.GOLD_SHOT,
            MechanicState.PURPLE_SHOT,
            MechanicState.STALL_RESET -> {
                if (elapsed > 260L || distToBall > screenW * 0.25f) finishMechanic(nowMs) else return
            }
            MechanicState.FAST_KICKOFF -> {
                if (elapsed > 1100L || distToBall < screenW * 0.065f || ballSpeed > 450f) finishMechanic(nowMs) else return
            }
            else -> {}
        }

        val ballAtCenter = abs(ball.x - screenW * 0.5f) < screenW * 0.045f &&
            ball.y in (screenH * 0.62f)..(screenH * 0.84f)
        if (ballAtCenter && ballSpeed < 65f && distToBall > screenW * 0.14f) {
            startMechanic(MechanicState.FAST_KICKOFF, nowMs)
            return
        }

        val headingToOwnGoal = if (attackDir < 0f) smoothVx > 220f else smoothVx < -220f
        val inDefensiveHalf = abs(ball.x - ownGoalX) < screenW * 0.38f
        if (headingToOwnGoal && inDefensiveHalf) {
            mechanicState = MechanicState.SHADOW_DEFENSE
            return
        }

        if (!cooldownOk) {
            mechanicState = MechanicState.NORMAL
            return
        }

        val style = BotConfig.proPlayStyle
        val carBehindBall = (ball.x - car.x) * attackDir > -20f
        val nearEnemyGoal = abs(ball.x - enemyGoalX) < screenW * 0.42f

        val canDo360 = (style == ProPlayStyle.FOCUS_360 || style == ProPlayStyle.AUTO_SMART)
        if (canDo360 &&
            ballHeightAboveFloor > screenH * 0.16f &&
            distToBall in (screenW * 0.13f)..(screenW * 0.34f) &&
            carBehindBall
        ) {
            spinDirection = if (attackDir < 0f) -1f else 1f
            lastSpinAngle = if (attackDir < 0f) PI.toFloat() else 0f
            startMechanic(MechanicState.SPIN_360, nowMs)
            return
        }

        if (style == ProPlayStyle.AUTO_SMART &&
            !isGrounded &&
            jumpCount >= 1 &&
            ballHeightAboveFloor > screenH * 0.24f &&
            abs(ball.x - car.x) < screenW * 0.055f &&
            (car.y - ball.y) in (screenH * 0.03f)..(screenH * 0.11f)
        ) {
            startMechanic(MechanicState.STALL_RESET, nowMs)
            return
        }

        val canDoShots = (style == ProPlayStyle.GOLD_AND_PURPLE || style == ProPlayStyle.AUTO_SMART)
        if (canDoShots &&
            distToBall < screenW * 0.13f &&
            (car.y - ball.y) in (screenH * 0.04f)..(screenH * 0.12f) &&
            carBehindBall
        ) {
            startMechanic(MechanicState.PURPLE_SHOT, nowMs)
            return
        }

        if (canDoShots &&
            distToBall < screenW * 0.14f &&
            carBehindBall &&
            (nearEnemyGoal || style == ProPlayStyle.GOLD_AND_PURPLE)
        ) {
            startMechanic(MechanicState.GOLD_SHOT, nowMs)
            return
        }

        mechanicState = MechanicState.NORMAL
    }

    private fun startMechanic(state: MechanicState, nowMs: Long) {
        mechanicState = state
        mechanicStartMs = nowMs
    }

    private fun finishMechanic(nowMs: Long) {
        mechanicState = MechanicState.NORMAL
        lastMechanicEndMs = nowMs
    }

    private fun executeFastKickoff(
        ball: Point2D,
        car: Point2D,
        screenW: Int,
        attackDir: Float,
        nowMs: Long
    ): BotAction {
        BotConfig.activeMechanicLabel = "Fast Kickoff ⚡"
        val dist = abs(ball.x - car.x)
        val canJump = (nowMs - lastJumpTimeMs) > 190L
        var jump = false

        if (canJump) {
            if (jumpCount == 0 && dist < screenW * 0.26f) {
                jump = true
                jumpCount = 1
                lastJumpTimeMs = nowMs
            } else if (jumpCount == 1 && dist < screenW * 0.095f) {
                jump = true
                jumpCount = 2
                lastJumpTimeMs = nowMs
            }
        }

        return BotAction(stickX = attackDir, stickY = -0.18f, jump = jump, boost = true)
    }

    private fun executeSpin360(
        ball: Point2D,
        car: Point2D,
        screenW: Int,
        attackDir: Float,
        nowMs: Long
    ): BotAction {
        BotConfig.activeMechanicLabel = "حركة 360° 🌀"
        val elapsed = (nowMs - mechanicStartMs).coerceAtLeast(0L)
        val spinDurationMs = 260f

        var jump = false
        if (jumpCount == 0 && (nowMs - lastJumpTimeMs) > 160L) {
            jump = true
            jumpCount = 1
            lastJumpTimeMs = nowMs
        }

        if (elapsed <= spinDurationMs) {
            val progress = (elapsed / spinDurationMs).coerceIn(0f, 1f)
            val baseAngle = if (attackDir < 0f) PI.toFloat() else 0f
            val currentAngle = baseAngle + spinDirection * (2f * PI.toFloat() * progress)
            val deltaSweep = currentAngle - lastSpinAngle
            lastSpinAngle = currentAngle

            return BotAction(
                stickX = cos(currentAngle).coerceIn(-1f, 1f),
                stickY = sin(currentAngle).coerceIn(-1f, 1f),
                jump = jump,
                boost = progress < 0.35f || progress > 0.75f,
                sweepArcRad = deltaSweep
            )
        } else {
            val dx = ball.x - car.x
            val dy = ball.y - car.y
            val dist = hypot(dx, dy)
            val angle = atan2(dy, dx)

            if (jumpCount == 1 && dist < screenW * 0.11f && (nowMs - lastJumpTimeMs) > 180L) {
                jump = true
                jumpCount = 2
                lastJumpTimeMs = nowMs
            }

            return BotAction(
                stickX = cos(angle).coerceIn(-1f, 1f),
                stickY = sin(angle).coerceIn(-1f, 1f),
                jump = jump,
                boost = true
            )
        }
    }

    private fun executeGoldShot(
        ball: Point2D,
        car: Point2D,
        screenW: Int,
        attackDir: Float,
        nowMs: Long
    ): BotAction {
        BotConfig.activeMechanicLabel = "Gold Shot 🟡"
        val dist = hypot(ball.x - car.x, ball.y - car.y)
        val elapsed = nowMs - mechanicStartMs

        var jump = false
        if (elapsed >= 95L && dist < screenW * 0.095f && (nowMs - lastJumpTimeMs) > 180L) {
            jump = true
            jumpCount = 2
            lastJumpTimeMs = nowMs
        }

        return BotAction(stickX = -attackDir, stickY = -0.15f, jump = jump, boost = elapsed < 80L)
    }

    private fun executePurpleShot(
        ball: Point2D,
        car: Point2D,
        screenW: Int,
        attackDir: Float,
        nowMs: Long
    ): BotAction {
        BotConfig.activeMechanicLabel = "Purple Shot 🟣"
        val dist = hypot(ball.x - car.x, ball.y - car.y)
        val elapsed = nowMs - mechanicStartMs

        return if (elapsed < 95L) {
            BotAction(stickX = attackDir * 0.2f, stickY = -1.0f, jump = false, boost = true)
        } else {
            val shouldPop = dist < screenW * 0.095f && (nowMs - lastJumpTimeMs) > 180L
            if (shouldPop) {
                jumpCount = 2
                lastJumpTimeMs = nowMs
            }
            BotAction(stickX = 0f, stickY = 0f, jump = shouldPop, boost = false, neutralStick = true)
        }
    }

    private fun executeStallReset(
        ball: Point2D,
        car: Point2D,
        screenW: Int,
        attackDir: Float,
        nowMs: Long
    ): BotAction {
        BotConfig.activeMechanicLabel = "Stall Reset 🔄"
        val elapsed = nowMs - mechanicStartMs
        val dist = hypot(ball.x - car.x, ball.y - car.y)

        return if (elapsed < 120L) {
            val tapStall = dist < screenW * 0.11f && (nowMs - lastJumpTimeMs) > 170L
            if (tapStall) {
                lastJumpTimeMs = nowMs
                jumpCount = 0
            }
            BotAction(stickX = 0f, stickY = 0f, jump = tapStall, boost = false, neutralStick = true)
        } else {
            val angle = atan2(ball.y - car.y, (ball.x + attackDir * 20f) - car.x)
            val followUpJump = (nowMs - lastJumpTimeMs) > 170L
            if (followUpJump) {
                lastJumpTimeMs = nowMs
                jumpCount = 1
            }
            BotAction(
                stickX = cos(angle).coerceIn(-1f, 1f),
                stickY = sin(angle).coerceIn(-1f, 1f),
                jump = followUpJump,
                boost = true
            )
        }
    }

    private fun executeShadowDefense(
        ball: Point2D,
        car: Point2D,
        screenW: Int,
        screenH: Int,
        floorY: Float,
        ownGoalX: Float,
        attackDir: Float,
        nowMs: Long
    ): BotAction {
        BotConfig.activeMechanicLabel = "Shadow Defense 🛡️"
        val predicted = predictBallPosition(ball, smoothVx, smoothVy, 0.30f, screenW.toFloat(), floorY)
        val interceptX = (predicted.x + ownGoalX) * 0.5f
        val dx = interceptX - car.x
        val dy = predicted.y - car.y
        val angle = atan2(dy, dx)

        val distToBall = hypot(ball.x - car.x, ball.y - car.y)
        val canJump = (nowMs - lastJumpTimeMs) > 210L
        var jump = false

        if (canJump && distToBall < screenW * 0.16f) {
            if (jumpCount == 0 && ball.y < floorY - screenH * 0.10f) {
                jump = true
                jumpCount = 1
                lastJumpTimeMs = nowMs
            } else if (jumpCount == 1 && distToBall < screenW * 0.085f) {
                jump = true
                jumpCount = 2
                lastJumpTimeMs = nowMs
                return BotAction(stickX = attackDir, stickY = -0.35f, jump = true, boost = true)
            }
        }

        return BotAction(
            stickX = cos(angle).coerceIn(-1f, 1f),
            stickY = sin(angle).coerceIn(-1f, 1f),
            jump = jump,
            boost = hypot(dx, dy) > screenW * 0.09f
        )
    }

    private fun executeNormalPlay(
        ball: Point2D,
        car: Point2D,
        screenW: Int,
        screenH: Int,
        floorY: Float,
        attackDir: Float,
        nowMs: Long
    ): BotAction {
        BotConfig.activeMechanicLabel = "هجوم ذكي ⚔️"
        val predicted = predictBallPosition(ball, smoothVx, smoothVy, 0.32f, screenW.toFloat(), floorY)

        val behindOffset = -attackDir * 48f
        val targetX = (predicted.x + behindOffset).coerceIn(45f, screenW - 45f)
        val targetY = predicted.y

        val dx = targetX - car.x
        val dy = targetY - car.y
        val distToTarget = hypot(dx, dy)
        val angle = atan2(dy, dx)

        val distToBall = hypot(ball.x - car.x, ball.y - car.y)
        val ballIsHigh = ball.y < floorY - (screenH * 0.13f)
        val canJump = (nowMs - lastJumpTimeMs) > 210L
        var jump = false

        if (canJump) {
            if (jumpCount == 0 && ballIsHigh && abs(ball.x - car.x) < screenW * 0.25f) {
                jump = true
                jumpCount = 1
                lastJumpTimeMs = nowMs
            } else if (jumpCount == 1 && distToBall < screenW * 0.09f) {
                jump = true
                jumpCount = 2
                lastJumpTimeMs = nowMs
            }
        }

        return BotAction(
            stickX = cos(angle).coerceIn(-1f, 1f),
            stickY = sin(angle).coerceIn(-1f, 1f),
            jump = jump,
            boost = distToTarget > screenW * 0.11f
        )
    }

    private fun predictBallPosition(
        pos: Point2D,
        vx: Float,
        vy: Float,
        lookAheadSec: Float,
        maxW: Float,
        floorY: Float
    ): Point2D {
        val gravity = 980f
        var predX = pos.x + vx * lookAheadSec
        var predY = pos.y + vy * lookAheadSec + 0.5f * gravity * lookAheadSec * lookAheadSec

        if (predX < 40f) predX = 40f + (40f - predX) * 0.8f
        if (predX > maxW - 40f) predX = (maxW - 40f) - (predX - (maxW - 40f)) * 0.8f
        if (predY > floorY) predY = floorY - (predY - floorY) * 0.75f
        if (predY < 50f) predY = 50f + (50f - predY) * 0.75f

        return Point2D(predX, predY)
    }
}
