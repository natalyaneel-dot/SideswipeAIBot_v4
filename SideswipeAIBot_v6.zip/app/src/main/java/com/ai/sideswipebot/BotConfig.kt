package com.ai.sideswipebot

import android.graphics.Rect

enum class TeamColor {
    BLUE,
    ORANGE
}

enum class TeamDetectMode {
    AUTO,
    FORCE_BLUE,
    FORCE_ORANGE
}

enum class ProPlayStyle {
    AUTO_SMART,
    FOCUS_360,
    GOLD_AND_PURPLE
}

object BotConfig {
    const val GAME_PACKAGE_NAME = "com.Psyonix.RL2D"

    @Volatile
    var isPaused: Boolean = true

    @Volatile
    var isLearningMode: Boolean = false

    @Volatile
    var onlyTouchInsideGame: Boolean = true

    // مرمى فريقك على اليمين والهجوم نحو اليسار (attackingRight = false)
    @Volatile
    var attackingRight: Boolean = false

    @Volatile
    var currentTeam: TeamColor = TeamColor.BLUE

    @Volatile
    var teamDetectMode: TeamDetectMode = TeamDetectMode.AUTO

    @Volatile
    var proPlayStyle: ProPlayStyle = ProPlayStyle.AUTO_SMART

    @Volatile
    var activeMechanicLabel: String = "جاهز (اضغط تشغيل)"

    @Volatile
    var currentForegroundPackage: String = ""

    @Volatile
    var learnedSamplesCount: Int = 0

    @Volatile
    var hudBoundsOnScreen: Rect = Rect(0, 0, 0, 0)
}
