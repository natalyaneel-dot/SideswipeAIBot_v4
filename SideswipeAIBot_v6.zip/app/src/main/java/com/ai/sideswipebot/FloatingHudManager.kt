package com.ai.sideswipebot

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.abs

class FloatingHudManager(private val context: Context) {

    companion object {
        private var activeInstance: FloatingHudManager? = null

        fun refreshButtonsFromAnywhere() {
            activeInstance?.refreshButtonStates()
        }
    }

    private var windowManager: WindowManager? = null
    private var rootView: LinearLayout? = null
    private var statusText: TextView? = null
    private var playPauseBtn: Button? = null
    private var learnBtn: Button? = null
    private var colorBtn: Button? = null
    private val mainHandler = Handler(Looper.getMainLooper())

    @SuppressLint("ClickableViewAccessibility")
    fun show() {
        if (!Settings.canDrawOverlays(context)) return
        if (rootView != null) return

        activeInstance = this
        windowManager = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager

        val container = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 12, 18, 12)
            background = GradientDrawable().apply {
                setColor(Color.argb(230, 15, 19, 28))
                cornerRadius = 26f
                setStroke(3, Color.argb(220, 0, 210, 255))
            }
        }

        val topRow = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }

        val dragHandle = TextView(context).apply {
            text = "⠿ اسحب | "
            setTextColor(Color.CYAN)
            textSize = 11.5f
        }

        val info = TextView(context).apply {
            text = "🔵 | كرة: ✗ | سيارة: ✗ | متوقف"
            setTextColor(Color.WHITE)
            textSize = 11.5f
            setPadding(0, 0, 12, 0)
        }

        val closeBtn = Button(context).apply {
            text = "✖"
            textSize = 11f
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.argb(180, 180, 35, 35))
            setPadding(14, 2, 14, 2)
            setOnClickListener {
                BotConfig.isPaused = true
                BotConfig.isLearningMode = false
                context.stopService(Intent(context, ScreenCaptureService::class.java))
            }
        }

        topRow.addView(dragHandle)
        topRow.addView(info)
        topRow.addView(closeBtn)

        val controlsRow = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, 8, 0, 0)
        }

        val toggleBtn = Button(context).apply {
            text = "▶ تشغيل"
            textSize = 11.5f
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.argb(210, 25, 145, 65))
            setPadding(16, 4, 16, 4)
            setOnClickListener {
                if (BotConfig.isPaused) {
                    BotConfig.isPaused = false
                    BotConfig.isLearningMode = false
                } else {
                    BotConfig.isPaused = true
                }
                refreshButtonStates()
            }
        }

        val trainBtn = Button(context).apply {
            text = "🧠 تعلّم مني"
            textSize = 11f
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.argb(200, 65, 75, 95))
            setPadding(14, 4, 14, 4)
            setOnClickListener {
                BotConfig.isLearningMode = !BotConfig.isLearningMode
                if (BotConfig.isLearningMode) {
                    BotConfig.isPaused = true
                }
                refreshButtonStates()
            }
        }

        val teamSwitchBtn = Button(context).apply {
            text = "لون: تلقائي"
            textSize = 10.5f
            setPadding(12, 4, 12, 4)
            setOnClickListener {
                BotConfig.teamDetectMode = when (BotConfig.teamDetectMode) {
                    TeamDetectMode.AUTO -> TeamDetectMode.FORCE_BLUE
                    TeamDetectMode.FORCE_BLUE -> TeamDetectMode.FORCE_ORANGE
                    TeamDetectMode.FORCE_ORANGE -> TeamDetectMode.AUTO
                }
                refreshButtonStates()
            }
        }

        controlsRow.addView(toggleBtn)
        controlsRow.addView(trainBtn)
        controlsRow.addView(teamSwitchBtn)

        container.addView(topRow)
        container.addView(controlsRow)

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 24
            y = 18
        }

        val dragListener = object : View.OnTouchListener {
            private var initialX = 0
            private var initialY = 0
            private var initialTouchX = 0f
            private var initialTouchY = 0f

            override fun onTouch(v: View?, event: MotionEvent): Boolean {
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        initialX = params.x
                        initialY = params.y
                        initialTouchX = event.rawX
                        initialTouchY = event.rawY
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        params.x = initialX + (event.rawX - initialTouchX).toInt()
                        params.y = initialY + (event.rawY - initialTouchY).toInt()
                        windowManager?.updateViewLayout(container, params)
                        updateHudBounds(container, params)
                        return true
                    }
                    MotionEvent.ACTION_UP -> {
                        updateHudBounds(container, params)
                        return abs(event.rawX - initialTouchX) > 10f || abs(event.rawY - initialTouchY) > 10f
                    }
                }
                return false
            }
        }

        dragHandle.setOnTouchListener(dragListener)
        info.setOnTouchListener(dragListener)

        windowManager?.addView(container, params)
        rootView = container
        statusText = info
        playPauseBtn = toggleBtn
        learnBtn = trainBtn
        colorBtn = teamSwitchBtn

        container.post { updateHudBounds(container, params) }
        refreshButtonStates()
    }

    private fun updateHudBounds(view: View, params: WindowManager.LayoutParams) {
        val w = if (view.width > 0) view.width else 520
        val h = if (view.height > 0) view.height else 140
        BotConfig.hudBoundsOnScreen = Rect(
            params.x - 20,
            params.y - 20,
            params.x + w + 20,
            params.y + h + 20
        )
    }

    fun refreshButtonStates() {
        mainHandler.post {
            playPauseBtn?.apply {
                if (BotConfig.isPaused) {
                    text = "▶ تشغيل"
                    setBackgroundColor(Color.argb(220, 25, 145, 65))
                } else {
                    text = "⏸ إيقاف"
                    setBackgroundColor(Color.argb(220, 210, 120, 20))
                }
            }

            learnBtn?.apply {
                if (BotConfig.isLearningMode) {
                    text = "🧠 يتعلم (${BotConfig.learnedSamplesCount})"
                    setBackgroundColor(Color.argb(220, 130, 55, 210))
                } else {
                    text = "🧠 تعلّم (${BotConfig.learnedSamplesCount})"
                    setBackgroundColor(Color.argb(200, 65, 75, 95))
                }
            }

            colorBtn?.text = when (BotConfig.teamDetectMode) {
                TeamDetectMode.AUTO -> "لون: تلقائي"
                TeamDetectMode.FORCE_BLUE -> "أزرق 🔵"
                TeamDetectMode.FORCE_ORANGE -> "برتقالي 🟠"
            }
        }
    }

    fun updateStatus(team: TeamColor, hasBall: Boolean, hasCar: Boolean) {
        val view = statusText ?: return
        mainHandler.post {
            val teamLabel = if (team == TeamColor.BLUE) "🔵" else "🟠"
            val ballMark = if (hasBall) "✓" else "✗"
            val carMark = if (hasCar) "✓" else "✗"
            view.text = "$teamLabel | كرة:$ballMark سيارة:$carMark | ${BotConfig.activeMechanicLabel}"
        }
    }

    fun hide() {
        activeInstance = null
        val view = rootView ?: return
        mainHandler.post {
            try {
                windowManager?.removeView(view)
            } catch (_: Exception) {
            }
            rootView = null
            statusText = null
            playPauseBtn = null
            learnBtn = null
            colorBtn = null
        }
    }
}
