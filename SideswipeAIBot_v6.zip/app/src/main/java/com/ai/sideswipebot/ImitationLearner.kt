package com.ai.sideswipebot

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.sqrt

data class LearnedSample(
    val relBallX: Float,
    val relBallY: Float,
    val ballVx: Float,
    val ballVy: Float,
    val carY: Float,
    val stickX: Float,
    val stickY: Float,
    val jump: Boolean,
    val boost: Boolean
)

class ImitationLearner(private val context: Context) {

    private val samples = ArrayList<LearnedSample>(4096)
    private val storageFile = File(context.filesDir, "sideswipe_learned_brain.json")

    private var prevCar: Point2D? = null
    private var prevCarVx: Float = 0f
    private var prevCarVy: Float = 0f
    private var prevSampleTimeMs: Long = 0L
    private var unsavedCounter: Int = 0

    init {
        loadFromDisk()
    }

    @Synchronized
    fun getSampleCount(): Int = samples.size

    @Synchronized
    fun clearMemory() {
        samples.clear()
        BotConfig.learnedSamplesCount = 0
        if (storageFile.exists()) {
            storageFile.delete()
        }
    }

    @Synchronized
    fun observePlayerFrame(
        ball: Point2D?,
        car: Point2D?,
        ballVx: Float,
        ballVy: Float,
        screenW: Int,
        screenH: Int,
        nowMs: Long
    ) {
        if (ball == null || car == null || screenW <= 0 || screenH <= 0) {
            prevCar = null
            return
        }

        val lastCar = prevCar
        val dt = (nowMs - prevSampleTimeMs) / 1000f
        if (lastCar == null || dt <= 0.015f || dt > 0.25f) {
            prevCar = car
            prevCarVx = 0f
            prevCarVy = 0f
            prevSampleTimeMs = nowMs
            return
        }

        val carVx = (car.x - lastCar.x) / dt
        val carVy = (car.y - lastCar.y) / dt

        val ax = (carVx - prevCarVx) / dt
        val ay = (carVy - prevCarVy) / dt

        prevCar = car
        prevCarVx = carVx
        prevCarVy = carVy
        prevSampleTimeMs = nowMs

        val stickX = (carVx / (screenW * 0.55f)).coerceIn(-1f, 1f)
        val stickY = (carVy / (screenH * 0.65f)).coerceIn(-1f, 1f)

        val inferredJump = ay < -(screenH * 1.45f) && carVy < -(screenH * 0.18f)
        val speedMag = hypot(carVx, carVy)
        val accelMag = hypot(ax, ay)
        val inferredBoost = speedMag > (screenW * 0.36f) || accelMag > (screenW * 1.15f)

        val distToBall = hypot(ball.x - car.x, ball.y - car.y)
        if (abs(stickX) < 0.08f && !inferredJump && !inferredBoost && distToBall > screenW * 0.35f) {
            return
        }

        val sample = LearnedSample(
            relBallX = ((ball.x - car.x) / screenW.toFloat()).coerceIn(-1f, 1f),
            relBallY = ((ball.y - car.y) / screenH.toFloat()).coerceIn(-1f, 1f),
            ballVx = (ballVx / screenW.toFloat()).coerceIn(-2f, 2f),
            ballVy = (ballVy / screenH.toFloat()).coerceIn(-2f, 2f),
            carY = (car.y / screenH.toFloat()).coerceIn(0f, 1f),
            stickX = stickX,
            stickY = stickY,
            jump = inferredJump,
            boost = inferredBoost
        )

        if (samples.size >= 4000) {
            samples.removeAt(0)
        }
        samples.add(sample)
        BotConfig.learnedSamplesCount = samples.size

        unsavedCounter++
        if (unsavedCounter >= 45) {
            unsavedCounter = 0
            saveToDisk()
        }
    }

    @Synchronized
    fun queryLearnedPolicy(
        ball: Point2D,
        car: Point2D,
        ballVx: Float,
        ballVy: Float,
        screenW: Int,
        screenH: Int
    ): BotAction? {
        if (samples.size < 25) return null

        val qRelX = ((ball.x - car.x) / screenW.toFloat()).coerceIn(-1f, 1f)
        val qRelY = ((ball.y - car.y) / screenH.toFloat()).coerceIn(-1f, 1f)
        val qBvx = (ballVx / screenW.toFloat()).coerceIn(-2f, 2f)
        val qBvy = (ballVy / screenH.toFloat()).coerceIn(-2f, 2f)
        val qCarY = (car.y / screenH.toFloat()).coerceIn(0f, 1f)

        val topK = ArrayList<Pair<Float, LearnedSample>>(8)

        for (s in samples) {
            val dRelX = (s.relBallX - qRelX) * 2.4f
            val dRelY = (s.relBallY - qRelY) * 2.4f
            val dVx = (s.ballVx - qBvx) * 1.1f
            val dVy = (s.ballVy - qBvy) * 1.1f
            val dCy = (s.carY - qCarY) * 1.0f

            val dist = sqrt(dRelX * dRelX + dRelY * dRelY + dVx * dVx + dVy * dVy + dCy * dCy)
            if (dist < 0.65f) {
                if (topK.size < 7) {
                    topK.add(Pair(dist, s))
                    topK.sortBy { it.first }
                } else if (dist < topK.last().first) {
                    topK[topK.lastIndex] = Pair(dist, s)
                    topK.sortBy { it.first }
                }
            }
        }

        if (topK.isEmpty()) return null

        var sumW = 0f
        var accStickX = 0f
        var accStickY = 0f
        var jumpScore = 0f
        var boostScore = 0f

        for ((dist, s) in topK) {
            val w = 1f / (dist + 0.04f)
            sumW += w
            accStickX += s.stickX * w
            accStickY += s.stickY * w
            if (s.jump) jumpScore += w
            if (s.boost) boostScore += w
        }

        return BotAction(
            stickX = (accStickX / sumW).coerceIn(-1f, 1f),
            stickY = (accStickY / sumW).coerceIn(-1f, 1f),
            jump = (jumpScore / sumW) > 0.42f,
            boost = (boostScore / sumW) > 0.45f
        )
    }

    @Synchronized
    fun saveToDisk() {
        try {
            val arr = JSONArray()
            for (s in samples) {
                val obj = JSONObject()
                obj.put("rx", s.relBallX.toDouble())
                obj.put("ry", s.relBallY.toDouble())
                obj.put("vx", s.ballVx.toDouble())
                obj.put("vy", s.ballVy.toDouble())
                obj.put("cy", s.carY.toDouble())
                obj.put("sx", s.stickX.toDouble())
                obj.put("sy", s.stickY.toDouble())
                obj.put("j", s.jump)
                obj.put("b", s.boost)
                arr.put(obj)
            }
            storageFile.writeText(arr.toString())
        } catch (_: Exception) {
        }
    }

    @Synchronized
    private fun loadFromDisk() {
        try {
            if (!storageFile.exists()) return
            val text = storageFile.readText()
            val arr = JSONArray(text)
            samples.clear()
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                samples.add(
                    LearnedSample(
                        relBallX = obj.getDouble("rx").toFloat(),
                        relBallY = obj.getDouble("ry").toFloat(),
                        ballVx = obj.getDouble("vx").toFloat(),
                        ballVy = obj.getDouble("vy").toFloat(),
                        carY = obj.getDouble("cy").toFloat(),
                        stickX = obj.getDouble("sx").toFloat(),
                        stickY = obj.getDouble("sy").toFloat(),
                        jump = obj.getBoolean("j"),
                        boost = obj.getBoolean("b")
                    )
                )
            }
            BotConfig.learnedSamplesCount = samples.size
        } catch (_: Exception) {
        }
    }
}
