package com.ai.sideswipebot

import android.app.Activity
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.AudioManager
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

class ScreenCaptureService : Service() {

    private var mediaProjection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private var workerThread: HandlerThread? = null
    private var workerHandler: Handler? = null

    private lateinit var learner: ImitationLearner
    private lateinit var brain: BotBrain
    private var hudManager: FloatingHudManager? = null
    private var audioManager: AudioManager? = null
    private var lastObservedVolume: Int = -1
    private var lastProcessMs = 0L

    private var blueVoteScore = 5
    private var lastBallScaled: Point2D? = null
    private var lastCarScaled: Point2D? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForegroundNotification()

        BotConfig.isPaused = true
        BotConfig.isLearningMode = false

        audioManager = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        lastObservedVolume = audioManager?.getStreamVolume(AudioManager.STREAM_MUSIC) ?: -1

        learner = ImitationLearner(applicationContext)
        brain = BotBrain(learner)
        hudManager = FloatingHudManager(this).apply { show() }

        val resultCode = intent?.getIntExtra("RESULT_CODE", Activity.RESULT_CANCELED) ?: return START_NOT_STICKY
        val data: Intent = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            intent.getParcelableExtra("DATA", Intent::class.java)
        } else {
            @Suppress("DEPRECATION")
            intent.getParcelableExtra("DATA")
        } ?: return START_NOT_STICKY

        val metrics = resources.displayMetrics
        val width = metrics.widthPixels / 2
        val height = metrics.heightPixels / 2
        val density = metrics.densityDpi

        workerThread = HandlerThread("BotSmartVisionThread").apply { start() }
        workerHandler = Handler(workerThread!!.looper)

        val projectionManager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        mediaProjection = projectionManager.getMediaProjection(resultCode, data)

        imageReader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
        virtualDisplay = mediaProjection?.createVirtualDisplay(
            "SideswipeSmartCapture",
            width,
            height,
            density,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            imageReader?.surface,
            null,
            workerHandler
        )

        imageReader?.setOnImageAvailableListener({ reader ->
            val image = reader.acquireLatestImage() ?: return@setOnImageAvailableListener
            val now = System.currentTimeMillis()
            if (now - lastProcessMs < 35L) {
                image.close()
                return@setOnImageAvailableListener
            }
            lastProcessMs = now

            // مراقبة زر خفض الصوت كإيقاف طوارئ بدون اعتراض أزرار الكنترول
            checkVolumeEmergencyStop()

            try {
                val plane = image.planes[0]
                val buffer = plane.buffer
                val pixelStride = plane.pixelStride
                val rowStride = plane.rowStride
                val rowPadding = rowStride - pixelStride * width

                val bitmap = Bitmap.createBitmap(
                    width + rowPadding / pixelStride,
                    height,
                    Bitmap.Config.ARGB_8888
                )
                bitmap.copyPixelsFromBuffer(buffer)

                val detectedTeam = when (BotConfig.teamDetectMode) {
                    TeamDetectMode.FORCE_BLUE -> TeamColor.BLUE
                    TeamDetectMode.FORCE_ORANGE -> TeamColor.ORANGE
                    TeamDetectMode.AUTO -> detectMyTeamColor(bitmap, width, height)
                }
                BotConfig.currentTeam = detectedTeam

                val (ballPos, carPos) = detectEntitiesGrid(bitmap, width, height, detectedTeam)
                bitmap.recycle()

                val realW = metrics.widthPixels
                val realH = metrics.heightPixels
                val scaledBall = ballPos?.let { Point2D(it.x * 2f, it.y * 2f) }
                val scaledCar = carPos?.let { Point2D(it.x * 2f, it.y * 2f) }

                if (scaledBall != null) lastBallScaled = scaledBall
                if (scaledCar != null) lastCarScaled = scaledCar

                hudManager?.updateStatus(detectedTeam, scaledBall != null, scaledCar != null)

                val action = brain.decide(scaledBall, scaledCar, realW, realH, now)
                if (action != null) {
                    BotAccessibilityService.instance?.executeAction(action, realW, realH)
                }
            } finally {
                image.close()
            }
        }, workerHandler)

        return START_STICKY
    }

    private fun checkVolumeEmergencyStop() {
        val am = audioManager ?: return
        val currentVol = am.getStreamVolume(AudioManager.STREAM_MUSIC)
        if (!BotConfig.isPaused) {
            if (lastObservedVolume != -1 && currentVol < lastObservedVolume) {
                BotConfig.isPaused = true
                BotConfig.isLearningMode = false
                BotConfig.activeMechanicLabel = "إيقاف طوارئ (زر الصوت)"
                FloatingHudManager.refreshButtonsFromAnywhere()
            }
        }
        lastObservedVolume = currentVol
    }

    private fun detectMyTeamColor(bitmap: Bitmap, w: Int, h: Int): TeamColor {
        val startX = if (BotConfig.attackingRight) (w * 0.37f).toInt() else (w * 0.54f).toInt()
        val endX = if (BotConfig.attackingRight) (w * 0.46f).toInt() else (w * 0.63f).toInt()
        val startY = (h * 0.02f).toInt()
        val endY = (h * 0.09f).toInt()

        var bluePixels = 0
        var orangePixels = 0

        for (y in startY until endY step 2) {
            for (x in startX until endX step 2) {
                val pixel = bitmap.getPixel(x, y)
                val r = Color.red(pixel)
                val g = Color.green(pixel)
                val b = Color.blue(pixel)

                if (b > 170 && b > r + 60) {
                    bluePixels++
                } else if (r > 180 && g in 60..175 && r > b + 80) {
                    orangePixels++
                }
            }
        }

        if (bluePixels > orangePixels + 4) {
            blueVoteScore = (blueVoteScore + 1).coerceAtMost(12)
        } else if (orangePixels > bluePixels + 4) {
            blueVoteScore = (blueVoteScore - 1).coerceAtLeast(0)
        }

        return if (blueVoteScore >= 6) TeamColor.BLUE else TeamColor.ORANGE
    }

    private fun detectEntitiesGrid(
        bitmap: Bitmap,
        w: Int,
        h: Int,
        myTeam: TeamColor
    ): Pair<Point2D?, Point2D?> {
        val cols = 24
        val rows = 14
        val cellW = (w / cols).coerceAtLeast(1)
        val cellH = (h / rows).coerceAtLeast(1)

        val ballGridCount = IntArray(cols * rows)
        val ballGridSumX = FloatArray(cols * rows)
        val ballGridSumY = FloatArray(cols * rows)

        val carGridCount = IntArray(cols * rows)
        val carGridSumX = FloatArray(cols * rows)
        val carGridSumY = FloatArray(cols * rows)

        val step = 3
        val minY = (h * 0.14f).toInt()
        val maxY = (h * 0.86f).toInt()
        val minX = (w * 0.05f).toInt()
        val maxX = (w * 0.95f).toInt()

        for (y in minY until maxY step step) {
            val row = (y / cellH).coerceIn(0, rows - 1)
            for (x in minX until maxX step step) {
                val pixel = bitmap.getPixel(x, y)
                val r = Color.red(pixel)
                val g = Color.green(pixel)
                val b = Color.blue(pixel)

                val maxC = max(r, max(g, b))
                val minC = min(r, min(g, b))
                val col = (x / cellW).coerceIn(0, cols - 1)
                val idx = row * cols + col

                if (minC > 220 && (maxC - minC) < 28) {
                    ballGridCount[idx]++
                    ballGridSumX[idx] += x.toFloat()
                    ballGridSumY[idx] += y.toFloat()
                } else if (myTeam == TeamColor.BLUE) {
                    if (b > 215 && g in 135..230 && r < 85) {
                        carGridCount[idx]++
                        carGridSumX[idx] += x.toFloat()
                        carGridSumY[idx] += y.toFloat()
                    }
                } else {
                    if (r > 220 && g in 90..175 && b < 62) {
                        carGridCount[idx]++
                        carGridSumX[idx] += x.toFloat()
                        carGridSumY[idx] += y.toFloat()
                    }
                }
            }
        }

        val ball = extractPeakCluster(
            ballGridCount, ballGridSumX, ballGridSumY, cols, rows,
            minClusterPixels = 3, maxClusterPixels = 65,
            prevPos = lastBallScaled?.let { Point2D(it.x / 2f, it.y / 2f) }
        )

        val rawCar = extractPeakCluster(
            carGridCount, carGridSumX, carGridSumY, cols, rows,
            minClusterPixels = 2, maxClusterPixels = 50,
            prevPos = lastCarScaled?.let { Point2D(it.x / 2f, it.y / 2f) }
        )

        val car = rawCar?.let { Point2D(it.x, it.y + 24f) }
        return Pair(ball, car)
    }

    private fun extractPeakCluster(
        counts: IntArray,
        sumX: FloatArray,
        sumY: FloatArray,
        cols: Int,
        rows: Int,
        minClusterPixels: Int,
        maxClusterPixels: Int,
        prevPos: Point2D?
    ): Point2D? {
        var bestScore = -1f
        var bestR = -1
        var bestC = -1

        for (r in 0 until rows) {
            for (c in 0 until cols) {
                val centerCount = counts[r * cols + c]
                if (centerCount < 1) continue

                var neighborhoodCount = 0
                var nx = 0f
                var ny = 0f

                for (dr in -1..1) {
                    val nr = r + dr
                    if (nr !in 0 until rows) continue
                    for (dc in -1..1) {
                        val nc = c + dc
                        if (nc !in 0 until cols) continue
                        val idx = nr * cols + nc
                        neighborhoodCount += counts[idx]
                        nx += sumX[idx]
                        ny += sumY[idx]
                    }
                }

                if (neighborhoodCount !in minClusterPixels..maxClusterPixels) continue

                val cx = nx / neighborhoodCount
                val cy = ny / neighborhoodCount
                var score = neighborhoodCount.toFloat()

                if (prevPos != null) {
                    val dist = hypot(cx - prevPos.x, cy - prevPos.y)
                    if (dist < 85f) {
                        score += (85f - dist) * 0.4f
                    }
                }

                if (score > bestScore) {
                    bestScore = score
                    bestR = r
                    bestC = c
                }
            }
        }

        if (bestR == -1) return null

        var totalCount = 0
        var totalX = 0f
        var totalY = 0f
        for (dr in -1..1) {
            val nr = bestR + dr
            if (nr !in 0 until rows) continue
            for (dc in -1..1) {
                val nc = bestC + dc
                if (nc !in 0 until cols) continue
                val idx = nr * cols + nc
                totalCount += counts[idx]
                totalX += sumX[idx]
                totalY += sumY[idx]
            }
        }

        return if (totalCount > 0) Point2D(totalX / totalCount, totalY / totalCount) else null
    }

    private fun startForegroundNotification() {
        val channelId = "sideswipe_bot_channel"
        val manager = getSystemService(NotificationManager::class.java)
        val channel = NotificationChannel(channelId, "Sideswipe Smart Bot", NotificationManager.IMPORTANCE_LOW)
        manager.createNotificationChannel(channel)

        val notification = Notification.Builder(this, channelId)
            .setContentTitle("Sideswipe Smart Bot v6.0")
            .setContentText("متوافق مع الكنترول • القائمة العائمة جاهزة")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .build()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(1, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(1, notification)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        learner.saveToDisk()
        hudManager?.hide()
        virtualDisplay?.release()
        imageReader?.close()
        mediaProjection?.stop()
        workerThread?.quitSafely()
    }
}
