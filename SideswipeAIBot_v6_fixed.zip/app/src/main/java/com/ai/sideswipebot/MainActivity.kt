package com.ai.sideswipebot

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var memoryInfoText: TextView

    private val captureLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK && result.data != null) {
            BotConfig.isPaused = true
            BotConfig.isLearningMode = false
            val serviceIntent = Intent(this, ScreenCaptureService::class.java).apply {
                putExtra("RESULT_CODE", result.resultCode)
                putExtra("DATA", result.data)
            }
            startForegroundService(serviceIntent)
            Toast.makeText(
                this,
                "ظهرت القائمة العائمة! افتح اللعبة والعب بالكنترول أو اضغط تشغيل",
                Toast.LENGTH_LONG
            ).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val tempLearner = ImitationLearner(applicationContext)

        val scroll = ScrollView(this)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(44, 56, 44, 44)
        }

        val title = TextView(this).apply {
            text = "Sideswipe Smart Bot v6.0"
            textSize = 23f
            setPadding(0, 0, 0, 8)
        }

        val safetyNote = TextView(this).apply {
            text = listOf(
                "• متوافق بالكامل مع أزرار يد الكنترول بدون أي تعارض.",
                "• يبدأ البوت متوقفاً لحماية شاشتك حتى تدخل اللعبة.",
                "• زر خفض الصوت يوقف البوت فوراً في أي لحظة."
            ).joinToString(separator = "\n")
            textSize = 13f
            setPadding(0, 0, 0, 20)
        }

        memoryInfoText = TextView(this).apply {
            text = "الذاكرة المتعلمة حالياً: ${tempLearner.getSampleCount()} موقف تدريبي"
            textSize = 14f
            setPadding(0, 0, 0, 16)
        }

        val gameLockSwitch = Switch(this).apply {
            text = "حماية اللمس: العمل داخل لعبة Sideswipe فقط"
            isChecked = BotConfig.onlyTouchInsideGame
            setPadding(0, 0, 0, 16)
            setOnCheckedChangeListener { _, isChecked ->
                BotConfig.onlyTouchInsideGame = isChecked
            }
        }

        val directionSwitch = Switch(this).apply {
            text = "مرمى فريقي على اليمين (الهجوم نحو اليسار)"
            isChecked = !BotConfig.attackingRight
            setPadding(0, 0, 0, 24)
            setOnCheckedChangeListener { _, isGoalRight ->
                BotConfig.attackingRight = !isGoalRight
            }
        }

        val btnOverlay = Button(this).apply {
            text = "1. تفعيل إذن القائمة العائمة (إلزامي)"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    val intent = Intent(
                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")
                    )
                    startActivity(intent)
                } else {
                    Toast.makeText(this@MainActivity, "إذن القائمة العائمة مفعّل ✓", Toast.LENGTH_SHORT).show()
                }
            }
        }

        val btnAccessibility = Button(this).apply {
            text = "2. تفعيل خدمة التحكم (Accessibility)"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
        }

        val btnStart = Button(this).apply {
            text = "3. إظهار القائمة العائمة وبدء الرؤية"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    Toast.makeText(this@MainActivity, "فعّل إذن القائمة العائمة (زر 1) أولاً!", Toast.LENGTH_LONG).show()
                    return@setOnClickListener
                }
                if (BotAccessibilityService.instance == null) {
                    Toast.makeText(this@MainActivity, "فعّل خدمة Accessibility (زر 2) أولاً!", Toast.LENGTH_LONG).show()
                    return@setOnClickListener
                }
                val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                captureLauncher.launch(manager.createScreenCaptureIntent())
            }
        }

        val btnClearMemory = Button(this).apply {
            text = "مسح ذاكرة التدريب المحفوظة"
            setOnClickListener {
                tempLearner.clearMemory()
                memoryInfoText.text = "الذاكرة المتعلمة حالياً: 0 موقف تدريبي"
                Toast.makeText(this@MainActivity, "تم مسح ذاكرة التدريب", Toast.LENGTH_SHORT).show()
            }
        }

        layout.addView(title)
        layout.addView(safetyNote)
        layout.addView(memoryInfoText)
        layout.addView(gameLockSwitch)
        layout.addView(directionSwitch)
        layout.addView(btnOverlay)
        layout.addView(btnAccessibility)
        layout.addView(btnStart)
        layout.addView(btnClearMemory)

        scroll.addView(layout)
        setContentView(scroll)
    }

    override fun onResume() {
        super.onResume()
        memoryInfoText.text = "الذاكرة المتعلمة حالياً: ${BotConfig.learnedSamplesCount} موقف تدريبي"
    }
}
